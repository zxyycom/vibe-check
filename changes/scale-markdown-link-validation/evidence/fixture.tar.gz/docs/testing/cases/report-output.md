# report-output

## Case WB-OUTPUT-MACHINE-V4-CONTRACT-001: Machine v4 publication contract

Owner: `docs/output.md#字段与完整集合验证`
Entities:

- `bun|src/machine-output/v4/publication.test.ts|machine publication v4 contract > projects four terminal Check outcomes and minimal supplemental Records`
- `bun|src/machine-output/v4/publication.test.ts|machine publication v4 contract > serializes a complete canonical two-file set that validates without a prefix`
- `bun|src/machine-output/v4/validation.test.ts|machine publication v4 validation > rejects v3 identities and malformed v4 rows`
- `bun|src/machine-output/v4/validation.test.ts|machine publication v4 validation > rejects mixed generations, composite duplicates, and unknown owners`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-data.test.ts|Package Run diagnostic logging output > keeps accepted handoff references out of machine and diagnostic publication`
  Proves:
- v4 publishes four Check terminal states, final data only on passed/failed states, and minimal `{ checkId, id, data }` supplemental Records.
- Complete-set validation rejects v3 and malformed/mixed input, closes composite identity/order and ownership, binds the complete Record set by fingerprint, and exposes no partial trusted prefix. The unchanged final-data projection remains the v4 compatibility boundary; version-matched provider-parser readback is package-consumer evidence, not a second machine contract.
- An accepted same-Run handoff reference can be read by an authorized consumer without adding a field or reference payload to the machine v4 run JSON.

## Case WB-OUTPUT-PUBLISHED-MATERIALS-001: Generated v4 publication materials remain canonical

Owner: `docs/output.md#随包材料与版本`
Entities:

- `bun|src/machine-output/v4/contract-materials.test.ts|machine publication v4 materials > serializes candidate bytes accepted by the current schemas`
  Proves:
- Runtime v4 serializer candidates are accepted by the current runtime schemas, without publishing a second contract-material helper. The packaged mixed-outcomes Definition/output correspondence is closed separately by the independent docs material evidence.

## Case WB-OUTPUT-PUBLICATION-LIFECYCLE-001: Publication lifecycle closes candidates before trusted paths

Owner: `docs/output.md#发布与并发读取边界`
Entities:

- `bun|src/machine-output/v4/lifecycle.test.ts|machine publication v4 lifecycle > preserves prior artifacts when candidate writing fails before replacement`
- `bun|src/machine-output/v4/lifecycle.test.ts|machine publication v4 lifecycle > preserves prior artifacts when the first canonical rename fails`
- `bun|src/machine-output/v4/lifecycle.test.ts|machine publication v4 lifecycle > replaces only canonical files while preserving legacy-named and unrelated files`
- `bun|src/machine-output/v4/lifecycle.test.ts|machine publication v4 lifecycle > cleans a partial replacement without deleting legacy-named or unrelated files`
  Proves:
- A successful publication replaces only the canonical pair. Candidate-write and first-rename failures preserve prior canonical bytes, clear owned temps, and preserve legacy-named and unrelated files without creating scanner-private `raw/` output.
- A first canonical-rename failure preserves that same prior set and cleans owned temps before any canonical replacement.
- A handled partial replacement removes canonical files and owned temps while preserving legacy-named and unrelated files, without creating scanner-private `raw/` output.

## Case WB-OUTPUT-DIRECTORY-TARGETS-001: Run outputs own only their exact files at explicit targets

Owner: `docs/development/project-run.md#run-outputs-and-compatibility-boundary`
Entities:

- `bun|src/project-run/outputs/directories.test.ts|Package Run output directories > writes independent machine and diagnostic files to one Definition-selected parent directory`
- `bun|src/project-run/outputs/directories.test.ts|Package Run output directories > uses an absolute RunControls target without changing Definition defaults`
  Proves:
- A Definition-selected root-external parent directory and a RunControls-selected absolute directory can each host machine publication and diagnostic logging together. The diagnostic readback is `path.relative(projectRoot, resolvedFile)` for the invocation-specific log, while machine publication owns only `run.json` and `records.ndjson`.
- Sharing a target directory does not create an `outputRoot`, containment promise, cleanup/retention protocol or coupled status: each output creates, replaces or cleans only its own exact files.

## Case WB-OUTPUT-RUN-PROGRESS-001: Product projects Check execution progress for people

Owner: `docs/guides/run-outputs.md#progress-rendering`
Entities:

- `bun|src/project-run/progress-rendering/renderer.lifecycle.test.ts|Package Run progress lifecycle presentation > maintains a TTY-only running region and assigns completion ordinals by settlement order`
- `bun|src/project-run/progress-rendering/renderer.lifecycle.test.ts|Package Run progress lifecycle presentation > keeps plain and dumb-terminal output append-only without running rows`
- `bun|src/project-run/progress-rendering/renderer.lifecycle.test.ts|Package Run progress lifecycle presentation > applies quiet-pass omission and unnumbered retained rows consistently in plain and dumb terminals`
- `bun|src/project-run/progress-rendering/renderer.lifecycle.test.ts|Package Run progress lifecycle presentation > clears quiet-pass running rows and retains unnumbered outcome blocks atomically`
- `bun|src/project-run/progress-rendering/renderer.lifecycle.test.ts|Package Run progress lifecycle presentation > reports configured policy separately from actual omissions and groups flag mismatches first`
- `bun|src/project-run/progress-rendering/renderer-formatting-statuses.test.ts|Package Run progress terminal formatting > formats a singular flag-condition group with a terminal-safe Check name`
- `bun|src/project-run/progress-rendering/renderer-formatting-statuses.test.ts|Package Run progress terminal formatting > formats every terminal status with measured duration or not run and only the safe reason code`
- `bun|src/project-run/progress-rendering/renderer-formatting-color.test.ts|Package Run progress terminal formatting > uses ANSI color only for message level labels on color-capable TTY writers`
- `bun|src/project-run/progress-rendering/renderer-formatting-final.test.ts|Package Run progress terminal formatting > renders an empty final TTY running region after zero-Check or fully settled progress`
- `bun|src/project-run/progress-rendering/renderer-formatting-writer-failure.test.ts|Package Run progress terminal formatting > propagates writer failures without swallowing them or attempting later writes`
- `bun|src/project-run/progress-rendering/terminal-statuses.test.ts|Package Run progress terminal statuses > groups flag-disabled Check names before execute while preserving their terminal facts`
- `bun|src/project-run/progress-rendering/terminal-statuses.test.ts|Package Run progress terminal statuses > groups only flag-disabled Checks outside an activated dependency closure`
- `bun|src/project-run/progress-rendering/terminal-statuses.test.ts|Package Run progress terminal statuses > renders a duration-bearing row for an executed not-applicable Check without a reason`
- `bun|src/project-run/progress-rendering/terminal-statuses.test.ts|Package Run progress terminal statuses > renders a duration-bearing row for an executed unavailable Check`
- `bun|src/project-run/progress-rendering/terminal-statuses.test.ts|Package Run progress terminal statuses > renders unstarted cancellation as execution-cancelled and not run`
- `bun|src/project-run/progress-rendering/timing.test.ts|Package Run progress timing > uses the shared monotonic interval for elapsed progress rather than summing parallel Check durations`
  Proves:

- Product-owned progress presents lifecycle status, measured duration or `not run`, controlled reason codes, and accepted terminal messages from lifecycle facts. It does not derive status or quiet-pass eligibility from final data or Record payloads: eligibility uses only the settled outcome and whether accepted Records/messages are present. At preparation completion, Product-created flag-condition mismatches form one atomic reason block with terminal-escaped Check names instead of repeated settled rows while retaining their terminal facts and counts; dependency-activated Checks retain their ordinary lifecycle rows and never enter that block. Other visible settled rows keep author-ordered message lines in one atomic block, while a message code is not terminal text.
- `omitQuietPassedRow` omits only a passed row with no accepted Record or message, never a running row or completion accounting. Its TTY running and retained settled rows are unnumbered; plain/dumb output stays append-only without running rows. The configured policy count remains distinct from actual renderer omissions, including flag-condition mismatches. TTY running rows use a single monotonic elapsed interval and heartbeat; capability-specific color applies only to level labels, human text is terminal-escaped, and writer failures remain observable.

## Case AUX-DOCS-MACHINE-ARTIFACTS-001: Independent v4 example acceptance

Owner: `docs/development/output-maintenance.md#package-材料的维护与验证`
Entities:

- `bun|scripts/validation/repository-material/machine-artifacts/validation.test.ts|independent repository material machine artifact validation > accepts exactly the current v4 example and positive JSON grammar variants`
- `bun|scripts/validation/repository-material/machine-artifacts/validation.test.ts|independent repository material machine artifact validation > rejects historical v2/v3 and focused v4 set mutations without a partial accepted set`
- `bun|scripts/validation/repository-material/machine-artifacts/validation.test.ts|independent repository material machine artifact validation > detects generated schema and example drift`
  Proves:
- The independent material validator accepts only the checked-in mixed-outcomes Definition/output set and current v4 schemas. It executes the Definition through the public Run to close built-in/custom Check and dependency-derived output drift, then independently verifies framing, schema, canonical JSON finite-number safety, composite identity/order, ownership and complete-set fingerprint invariants without importing the Product validator as its artifact acceptance authority. Its canonical text sorts nested keys, normalizes negative zero and expands shared values, while rejecting cycles, getters, sparse arrays, symbols and non-JSON values. Published-schema and example byte drift are rejected by their generators.

## Case AUX-DOCS-HISTORICAL-MACHINE-SCHEMAS-001: Current v4 example validation rejects historical machine identities

Owner: `docs/development/output-maintenance.md#package-材料的维护与验证`
Entities:

- `bun|scripts/validation/repository-material/machine-artifacts/validation.test.ts|independent repository material machine artifact validation > rejects historical v2/v3 and focused v4 set mutations without a partial accepted set`
  Proves:
- The current docs artifact validator rejects v2 and v3 run/Record schema identities; it accepts current v4 artifacts only.

## Case WB-OUTPUT-MAINTENANCE-REMINDER-001: Maintenance reminders use the generic v4 final-data row

Owner: `docs/checks/maintenance-reminders.md#效果与结果`
Entities:

- `bun|src/package-checks/maintenance-reminders/machine-publication.test.ts|maintenance reminders > publishes one generic final-data Check row without Records or messages`
  Proves:
- A due advisory maintenance reminder publishes exactly one ordinary `maintenance-reminders` passed Check outcome with its ordered assessment final data. It publishes no supplemental Records, entry-level machine rows, terminal messages, or quiet-pass presentation fields.
