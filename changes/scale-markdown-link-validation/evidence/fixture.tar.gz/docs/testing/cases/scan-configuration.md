# scan-configuration

## Case WB-PROJECT-DEFINITION-001: Recursive Project Definition grammar fails closed

Owner: `docs/development/project-definition.md#recursive-check-tree`
Entities:

- `bun|src/project-definition/project-definition.authoring-defaults.test.ts|Project Definition > creates a plain value with Product-owned authoring defaults`
- `bun|src/project-definition/project-definition.recursive-checks.test.ts|Project Definition > normalizes ordinary recursive Checks without a Record catalog`
- `bun|src/project-definition/project-definition.recursive-checks.test.ts|Project Definition > preserves shared container occurrences and warning paths`
- `bun|src/project-definition/project-definition.recursive-checks.test.ts|Project Definition > rejects cyclic and repeated executable declarations before shared expansion`
- `bun|src/project-definition/project-definition.scheduling-inheritance.test.ts|Project Definition > uses exact scheduling inheritance and rejects retired catalog fields`
- `bun|src/project-definition/project-definition.scheduling-inheritance.test.ts|Project Definition > restores sibling collections after exact and overlapping inherited edits`
- `bun|src/project-definition/project-definition.scheduling-inheritance.test.ts|Project Definition > materializes inherited collection prefixes only for executable consumers`
- `bun|src/project-definition/project-definition.scheduling-inheritance.test.ts|Project Definition > normalizes signed admission priority by nearest explicit ancestor`
- `bun|src/project-definition/project-definition.scheduling-inheritance.test.ts|Project Definition > normalizes closed named resource capacities and exact replacement claims`
- `bun|src/project-definition/project-definition.quiet-pass-policy.test.ts|Project Definition > normalizes executable quiet-pass policy and rejects other declarations`
- `bun|src/project-definition/project-definition.quiet-pass-policy.test.ts|Project Definition > ignores inherited quiet-pass policy while defaulting executable Checks`
- `bun|src/project-definition/project-definition.fingerprint.test.ts|Project Definition > fingerprints canonical declarative data without retaining callback functions`
- `bun|src/project-definition/project-definition.typed-provider.test.ts|Project Definition > accepts parsers only on executable providers and excludes them from declarative identity`
- `bun|src/project-run/outputs/directories.test.ts|Package Run output directories > accepts child, parent, and absolute directories in Definition and RunControls`
- `bun|src/project-run/run-prepared-facts.test.ts|Package Run prepared facts > revalidates the same mutable authored Definition for each Run without revising earlier facts`
  Proves:

- Recursive ordinary Checks normalize only the declared executable/container grammar. Exact `dependsOn`, `observes`, and `mutex` scheduling collections use explicit `inherit` independently; scalar `maxParallel` and signed `admissionPriority` inherit the nearest explicit value, while named `resourceClaims` inherit the nearest explicit complete mapping and support explicit replacement or clearing. Root capacities and claims are closed positive-safe-integer mappings; unknown or oversized claims fail before author work. Priority omission and explicit `0` share canonical identity, and canonical resources participate in declarative identity. Executable `enabledByFlags` and normalized `omitQuietPassedRow` are canonical declarative identity. The closed scheduler policy defaults to canonical `static` and accepts exact `static`, `custom` with nested simple/prepared strategy, or `custom`; custom strategy kind enters the fingerprint, while callback identity, caller-owned strategy options, and history location stay outside declarative identity. Nonconforming, retired or unknown authoring fails closed; trusted execution/parser functions remain outside declarative fingerprints.
- Canonical declarative data preserves ordinary authored values without retaining author-controlled prototypes or callback identity; an executable provider must retain its parser while containers and malformed parser declarations fail closed. An exact `handoff: true` declaration is allowed only on an executable provider, preserves internal identity only to execution, and is stripped before declarative fingerprinting; container, non-true or own-undefined declarations fail closed.
- Definition and RunControls use one closed directory grammar for machine publication and diagnostic logging: child, parent and absolute targets are valid without output I/O; empty, U+0000 and unknown output keys remain configuration failures before callbacks run.
- Reusing a mutable authored Definition across Runs revalidates current Check identity, canonical options and resource capacities; later mutation changes the new graph/fingerprint without revising earlier frozen facts. The prepared Run path preserves the standalone validation/normalization declarative fingerprint for the same input.
- 循环包含关系及同对象/不同对象的重复 executable ID 在 Definition 边界拒绝；公开 Run 返回 `configuration / invalid-project-definition`，定位 `definition.checks`，callback 调用数为零。测试共享 DAG 的反射访问随首次路径深度增长；非循环共享 container 保留每个声明位置的 warning path，container ID 可重复。
- 三类继承集合保持先 remove 后 add、exact 清空/替换、排序去重与冻结快照；可执行父子节点、兄弟节点和独立根的集合互相隔离。单 executable 深继承只为最终有效集合排序，中间容器不物化增长前缀。

## Case WB-SCHEDULER-CONTEXT-DECLARATION-001: Scheduler context demand has closed phase grammar

Owner: `docs/development/project-definition.md#scheduler-配置`
Entities:

- `bun|src/project-definition/scheduler-context-validation.test.ts|Scheduler context declaration validation > snapshots closed phase needs without invoking accessors and rejects malformed grammar`
- `bun|src/project-definition/scheduler-context-validation.test.ts|Scheduler context declaration validation > validates Definition descriptors before callbacks and excludes needs from the declarative fingerprint`
  Proves:

- Scheduler descriptors reject unknown fields, wrong-phase tokens, sparse arrays and accessors without invoking author code. Valid needs are detached, deduplicated and frozen; functions, omitted or own-undefined needs, and an empty list all request no context fields.
- Definition validates descriptors before callbacks run, and changing callback demand does not change the declarative fingerprint.

## Case WB-PROJECT-DEFINITION-FLAG-ENABLEMENT-001: Flag enablement is closed executable identity

Owner: `docs/development/project-definition.md#flag-enabled-checks`
Entities:

- `bun|src/project-definition/project-definition.flag-enablement.test.ts|Project Definition > normalizes executable flag enablement as declarative identity`
- `bun|src/project-definition/project-definition.flag-enablement.test.ts|Project Definition > normalizes opt-in dependency propagation as declarative identity`
- `bun|src/project-definition/project-definition.flag-enablement.test.ts|Project Definition > rejects malformed and container flag enablement`
  Proves:

- `enabledByFlags.when` and its recursive children use nonempty string atoms as the only leaf, with compatible raw operator AST. Direct `all` / `any` / `none` / `notAll` / `exactlyOne` / `not` builders return that same AST and preserve nesting, child order and multiplicity, while `changeFlag` retains its protected literal token. Definition copies and freezes an unchanged AST for canonical identity and fingerprint; literal opt-in `propagateDependsOn: true` changes declarative identity, while omission preserves direct-selection behavior.
- Empty or malformed operator sets, empty string atoms, unknown control fields, non-literal propagation values, container declarations, `{ kind: "flag" }` nodes and removed `{ flags, mode }` shorthand fail Definition validation. Configured Git change sources require only a safe nonempty comparison revision: option-like and U+0000-containing values fail Definition validation before author work.

## Case WB-PROJECT-CHANGES-AUTHORING-001: Change regions snapshot complete native patterns

Owner: `docs/development/project-definition.md#project-changes`
Entities:

- `bun|src/project-definition/project-changes.test.ts|Project Definition changes > snapshots complete pattern regions with stable frozen identity`
- `bun|src/project-definition/project-changes.test.ts|Project Definition changes > rejects malformed regions without relaxing required fields or closed input safety`
  Proves:

- Public change regions 只接受必填 patterns；Definition 复制并深冻结数组，完整配置形成稳定 fingerprint，后续 author mutation 不改变规范结果。
- 旧 include/exclude、undefined/null/非法或 accessor/sparse 数组、额外/symbol/inherited 字段及缺失 source/revision 在 Definition 边界拒绝，不执行 getter。

## Case AUX-PACKAGE-CHECK-COMPOSITION-001: Package Check options remain Definition-opaque before preparation

Owner: `docs/development/project-definition.md#package-provided-check-composition`
Entities:

- `bun|src/project-definition/project-definition.options-preparation.test.ts|Project Definition > accepts ordinary authored JSON options while their Check preparation owns domain validation`
- `bun|src/project-definition/project-definition.options-preparation.test.ts|Project Definition > accepts ordinary JSON Schema options while their Check preparation owns domain validation`
  Proves:

- Definition preserves authored package Check options as declarative JSON without interpreting their domain shape; the owning Check preparation, not Definition normalization, decides whether ordinary JSON or JSON Schema options are valid before execution.

## Case AUX-PUBLIC-AUTHORING-TYPES-001: Public authoring values and declarations remain usable from an installed package

Owner: `docs/development/project-definition.md#public-authoring-surface`
Entities:

- `bun|scripts/package/public-api-inventory.test.ts|public API inventory > publishes only the approved runtime and type roots`
- `bun|scripts/package/candidate/external-consumer/type-acceptance.test.ts|external consumer type fixture uses only its public strictness profile`
- `bun|scripts/package/candidate/external-consumer/type-acceptance.test.ts|external consumer type acceptance`
  Proves:

- The public package uses the `@zxyycom/vibe-check` import specifier and exposes only the documented generic authoring/run/Finding-presentation/waiver/cache/admission-simulation operations, direct flag-condition builders and `changeFlag`, the `defineAdmissionPolicy` inference helper, the generic `commandCheck` constructor, one composable default project-file selection, eight package-provided fixed Check functions, eight named final-data parsers, and their required authoring/resolved/final/Record/reason/cache/admission-policy/admission-state type roots. `commandCheck` exposes only its six declared constructor/environment/output/final-data/unavailable-reason/Check types; private process runner types are not public roots. Change-flag authoring exposes one string-leaf `CheckFlagCondition`, `{ when, propagateDependsOn? }` enablement, Git source/region/configuration, and file-centric evidence types. The retired `CheckFlagConditionInput` and `CheckFlagEnablementMode` roots are absent, not internal; only Definition-normalized controls and Git acquisition helpers remain internal.
- An installed consumer can declare `handoff: true` on a `defineCheck` provider, infer provider-aware `dependencies.get(provider)` data/reference types without manual generics, and observe strict identity only within the authorized current Run. The returned reference is absent from installed Run and machine evidence rather than becoming a published contract.
- An ancestry-external TypeScript consumer imports and typechecks that public surface without casts or manual dependency-read generics; the same acceptance reads the installed declaration owners directly and requires the documented `defineCheck` / `run` summaries, remarks, parameters, returns and example rather than constructing a second compiler program after `tsgo`. The consumer can declare a typed Git change configuration, build a nested string-atom condition with every direct builder, retain the `changeFlag("source")` literal type, read optional `project.changes` from the third `prepare` argument and `execute`, and distinguish successful files from unavailable evidence. It can declare `observes`, enumerate its direct settled outcome through the callback-local `dependencies.list()` surface, and still uses the producing parser for final data. It can create standalone immutable admission graph branches and read the same callback `admissionState`, while the closed strategy result remains only `select(taskId)` or `wait`. It can author a simple or prepared custom strategy over frozen graph/decision/terminal DTOs: `decide` must synchronously return exact `select(taskId)` or `wait`, prepared may asynchronously form its Run-local closure and optional `terminalEffect`, and retired `proposeAdmission` plus unknown nested fields are rejected in installed declarations. It can import the learned strategy factory, pass caller-owned history identity and model options, and install its returned prepared strategy through the same custom hook. The caller-keyed cache parser must likewise synchronously return a non-thenable typed value. The deeply frozen file-selection baseline composes into a consumer-owned selection, and every package Check export is callable and retains its typed parser relation.
- Under `strict + noUncheckedIndexedAccess + exactOptionalPropertyTypes`, installed callback declarations preserve non-empty and discriminated tuple structure while retaining `unknown` leaf uncertainty; the consumer fixture does not inherit implementation-only control-flow rules. Consumer-local copies of the locked `@types/node` and its `undici-types` dependency provide real standard-library declarations for the examples instead of a hand-written process stub. The acceptance verifies literal `checkId`, exact environment, discard output, final-data/unavailable-reason types, and every ordinary selection, relation and scheduling field accepted by `commandCheck`; its public `execute` return remains `CheckResult<CommandCheckFinalData>` or its Promise.
- Installed Markdown lint declarations expose `MarkdownLintFindingIdentity`, `MarkdownLintFindingWaiver` and `MarkdownLintFindingWaiverAuditRecordData`; identity authoring requires the closed public rule and complete range, resolved waivers remain readonly, and consumers can narrow the lint/input-rejected/waiver-audit Record union by `kind`.
- Installed waiver helper declarations support named options and generic inference with omitted, `undefined`, empty and non-empty waiver inputs; `findings` and `identify` remain required, `null` is rejected, and returned audits remain complete and readonly.
- The installed root exposes `defineSchedulerContextCallback` and its six phase/input/result/descriptor types. Helper-authored callbacks retain their declared field guarantees through direct Definition and prepared strategy slots; wrong-phase needs, undeclared field access, asynchronous decisions and unknown descriptor fields fail typechecking. Widened or union-valued needs do not promise fields that may be absent. Legacy function authoring retains full contextual types; the broadened input slots are not directly callable without narrowing.

## Case API-ADMISSION-POLICY-AUTHORING-001: Admission policy helper preserves exact public authoring

Owner: `docs/guides/scheduling.md#自定义准入-policy`
Entities:

- `bun|src/package-tools/admission-policy/define-admission-policy.test.ts|admission policy authoring > preserves policy identity and closed generic authoring types`
  Proves:

- `defineAdmissionPolicy` returns the original policy value while preserving static and custom literal inference. Its generic authoring surface contextually types simple and synchronous/asynchronous prepared callbacks, admits only synchronous decision proposals, and rejects unknown fields at the static, custom-policy and prepared-result boundaries.

## Case AUX-MARKDOWN-LINK-OPTIONS-001: Markdown Link authoring defaults remain partial and bounded

Owner: `docs/checks/markdown-link-validation.md#参数与默认配置`
Entities:

- `bun|src/package-checks/markdown-link-validation/default-check.test.ts|default Check direct callbacks > materializes bounded Markdown Link defaults and rejects malformed resolved options`
  Proves:
- `markdownLinkValidation(options?)` accepts closed partial authoring fields, derives its precise case-insensitive Markdown include from the public source/exclude baseline, defaults `findingPolicy` to non-blocking, and fills/freezes the complete bounded resolved policy. Its cache branch defaults to exact `{ enabled: false }`; only exact enabled/disabled alternatives are accepted, enabled requires a non-empty absolute directory without U+0000, and that resolved branch participates in declarative identity. It exposes its final-data parser. Unknown authoring fields or an unsupported policy fail synchronously; malformed complete replacements fail in the owning Check before execution with an actionable message.

## Case WB-MAINTENANCE-REMINDER-CONFIGURATION-001: Specialized maintenance reminder authoring is one closed ordinary Check

Owner: `docs/checks/maintenance-reminders.md#构造器项目声明`
Entities:

- `bun|src/package-checks/maintenance-reminders/maintenance-reminders.test.ts|maintenance reminders > constructs one fixed Check, validates full composed policy, and fingerprints entries`
- `bun|src/package-checks/maintenance-reminders/maintenance-reminders.test.ts|maintenance reminders > accepts object input while preserving the entries overload and package-owned Git options`
  Proves:
- `maintenanceReminders(entries)` creates exactly one fixed-ID ordinary Check with `omitQuietPassedRow: true` and package-owned Git options; it does not create a child Check collection. Its object input preserves the entries overload, accepts a custom identity plus ordinary project declaration fields, retains the default display name, and projects `omitQuietPassedRow: false` as an omitted raw Check field.
- The object input keeps Git package-owned: returned resolved options retain the fixed Git executable, and a supplied `git` branch is rejected. Its complete composed options accept only dense, uniquely identified reminder policies with full immutable bases, positive limits, non-empty messages, recognized modes, and a complete Git executable branch. It exposes a discriminated final-data parser; invalid/unknown replacement data settles the owning Check unavailable in preparation with an actionable message, while policy changes affect the declarative fingerprint.

## Case WB-PROGRESS-PREVIEW-DEFINITION-001: Progress preview Definition is defaulted and callback-free declarative identity

Owner: `docs/development/project-definition.md#progress-preview-配置`
Entities:

- `bun|src/project-definition/project-definition.authoring-defaults.test.ts|Project Definition > creates a plain value with Product-owned authoring defaults`
- `bun|src/project-definition/project-definition.fingerprint.test.ts|Project Definition > fingerprints canonical declarative data without retaining callback functions`
  Proves:

- Definition defaults Record/message preview limits to `5`/`5`, text budget to `240`, and formatter to `null`; compatible direct `{ enabled }` input receives the same frozen resolved policy. Closed validation rejects invalid limits, formatter values and unknown fields even when progress is disabled.
- Normalized numeric policy and formatter `default`/`custom` kind enter declarative identity. Omission and explicit defaults share a fingerprint; distinct callback identities share the `custom` projection, while a policy value or formatter kind change does not.

## Case WB-PROGRESS-PREVIEW-OVERRIDE-001: RunControls override progress preview fields without changing Definition policy

Owner: `docs/development/project-run.md#run-outputs-and-compatibility-boundary`
Entities:

- `bun|src/project-run/controls/outputs-override-validation.test.ts|Package Run output overrides > merges bounded progress previews field by field and clears a Definition formatter`
  Proves:

- RunControls applies only explicit preview fields: `0` is an effective count, `undefined` preserves the Definition field, and `formatter: null` clears the authored callback without mutating it. The accepted override remains frozen.

## Case WB-OUTPUT-OVERRIDE-DIAGNOSTIC-001: 输出覆盖值错误可定位且不执行作者代码

Owner: `docs/development/project-run.md#run-outputs-and-compatibility-boundary`
Entities:

- `bun|src/project-run/controls/outputs-override-validation.test.ts|Package Run output overrides > locates rejected output fields with closed expectations and without reading accessors`
- `bun|src/project-run/run-controls.test.ts|Package Run > rejects invalid closed controls while a blocked preparation settles unavailable before execution`
  Proves:

- 无效 output object 与已知 leaf 返回对应 controls path、invalid-value 和封闭的合法值提示；unknown key 返回具体字段 path 与 unknown-key，不附加 expected 或回显被拒绝值。
- disabled output 的显式字段仍被校验；accessor 不被执行，Run 在无效目录、未知 output 字段或非法 preview 配置下返回 configuration，且不执行 Check author callback。

## Case WB-PROGRESS-OUTPUT-001: Progress rendering is a Run-owned output

Owner: `docs/development/project-run.md#run-outputs-and-compatibility-boundary`
Entities:

- `bun|src/project-run/progress-rendering/invocation-progress.test.ts|Package Run progress rendering outputs > presents enabled Package Run progress through the injected plain writer`
- `bun|src/project-run/progress-rendering/invocation-progress.test.ts|Package Run progress rendering outputs > tees final progress while retaining canonical Check durations in RunResult`
- `bun|src/project-run/progress-rendering/invocation-progress.test.ts|Package Run progress rendering outputs > keeps terminal progress when its selected file target cannot be opened`
- `bun|src/project-run/progress-rendering/invocation-progress-failures.test.ts|Package Run progress rendering outputs > does not create or write a progress writer when Package Run progress is disabled`
- `bun|src/project-run/progress-rendering/invocation-progress-failures.test.ts|Package Run progress rendering outputs > contains progress writer failures while preserving completed Check facts`
- `bun|src/project-run/progress-rendering/invocation-progress-failures.test.ts|Package Run progress rendering outputs > contains a Record preview write failure while retaining accepted Check and Record facts`
- `bun|src/project-run/progress-rendering/invocation-progress-failures.test.ts|Package Run progress rendering outputs > contains formatter failure and observes returned Promise rejection without revising accepted facts`
- `bun|src/project-run/progress-rendering/invocation-progress-failures.test.ts|Package Run progress rendering outputs > previews only accepted Records when Record misuse settles its Check unavailable`
- `bun|src/project-run/progress-rendering/invocation-progress-heartbeat.test.ts|Package Run progress rendering outputs > schedules one 5-second TTY heartbeat and cancels it after the last Check settles`
- `bun|src/project-run/progress-rendering/result-priority.test.ts|Package Run progress result priority > keeps an execute failure distinct when progress presentation has failed`
- `bun|src/project-run/progress-rendering/result-priority.test.ts|Package Run progress result priority > mutes ordinary progress events after a settled writer failure while preserving final facts`
- `bun|src/project-run/progress-rendering/result-priority.test.ts|Package Run progress result priority > resolves closed output statuses without replacing primary results`
- `bun|src/project-run/progress-rendering/default-outputs.test.ts|Package Run default outputs > keeps default progress and publication outputs independently successful`
- `bun|src/project-run/progress-rendering/result-priority.test.ts|Package Run progress result priority > keeps execution cancellation distinct when progress presentation has failed`
- `bun|src/project-run/progress-rendering/invocation-progress-failures.test.ts|Package Run progress rendering outputs > contains a TTY rewrite failure without leaving Check or Record facts open`
- `bun|src/project-run/progress-rendering/invocation-progress-record-previews.test.ts|Package Run progress rendering outputs > omits a quiet pass before preview formatting without changing its final facts`
- `bun|src/project-run/progress-rendering/invocation-progress-record-previews.test.ts|Package Run progress rendering outputs > renders accepted quiet-pass Records while retaining complete Records and messages in final facts`
- `bun|src/project-run/progress-rendering/invocation-progress-record-previews.test.ts|Package Run progress rendering outputs > applies RunControls preview limits and formatter to terminal and tee bytes without changing facts`
- `bun|src/project-run/progress-rendering/renderer-formatting-records.test.ts|Package Run progress Record and message previews > renders independent bounded Record and message previews without changing their source facts`
- `bun|src/project-run/progress-rendering/invocation-output-failure.test.ts|Package Run output failure composition > continues output publication after a progress writer failure`
- `bun|src/project-run/progress-rendering/invocation-output-failure.test.ts|Package Run output failure composition > returns output facts when machine publication alone fails`
- `bun|src/project-run/progress-rendering/invocation-output-failure.test.ts|Package Run output failure composition > keeps both failed outputs and prioritizes progress rendering`
  Proves:
- Disabling progress rendering constructs neither writer, tee, refresh schedule nor Record/message preview, and does not affect Check execution or complete facts.
- Enabled TTY progress owns one 5-second heartbeat while Checks are running and cancels it when the last running Check settles; the refresh remains inside presentation and does not alter Check facts.
- A progress writer failure, including one raised by a Record preview or scheduled TTY heartbeat rewrite, cancels the heartbeat, marks only `outputs.progressRendering` failed, and retains closed Check/Record facts. A caller-selected `progressLogFile` tees the same bytes after terminal output, preserving visible settled-row duration and final execution/counts/elapsed; complete canonical Check durations, including `null`, remain in `RunResult`, and a file target failure cannot suppress terminal output.
- A policy-enabled quiet pass is omitted before preview formatting without changing its final facts. Every retained settled block independently previews its configured number of accepted Records and messages. By default, a Record uses only its local ID plus canonical JSON data; both kinds terminal-escape then truncate at their configured Unicode code-point budget with the marker included and report their own exact omitted count. A synchronous formatter sees frozen default text only for count-selected items, Records precede messages, and its empty string remains presented; it cannot change labels, ordering or facts. Only Records accepted before settlement are previewed; rejected or fabricated Record data never appears. Formatter throw/non-string results—including real rejected Promises with a caller-owned `then`—fail only progress rendering without reading arbitrary thenables or revising snapshot Records/`RunResult.checkMessages`; a policy-enabled passed Check with either kind remains visible.
- Machine publication failure marks `outputs.machinePublication` failed and returns `kind: "output"` with final facts. After all output owners close, result resolution is pure: a completed candidate upgrades to `output` using failed-output priority—progress rendering, machine publication, diagnostic logging, then terminal effects; an existing `output` candidate reselects that same priority; `planning`, `cancelled` and `execution` candidates retain their primary kind while exposing every closed status. When progress rendering and machine publication both fail, both statuses remain observable and the result diagnostic selects progress rendering.

## Case WB-DIAGNOSTIC-LOGGING-OUTPUT-001: Diagnostic logging is a Product-owned Run output

Owner: `docs/development/human-output.md#diagnostic-logging-maintenance`
Entities:

- `bun|src/project-run/progress-rendering/default-outputs.test.ts|Package Run default outputs > keeps default progress and publication outputs independently successful`
- `bun|src/project-run/diagnostic-logging/logger.test.ts|Project Run diagnostic logger detail safety > rejects descriptor-unsafe details without invoking author hooks`
- `bun|src/project-run/diagnostic-logging/logger.test.ts|Project Run diagnostic logger observation formatting > renders bounded filterable facts without changing their format`
- `bun|src/project-run/diagnostic-logging/logger.test.ts|Project Run diagnostic logger > correlates explicit owner channels with one invocation-wide sequence`
- `bun|src/project-run/diagnostic-logging/logger.test.ts|Project Run diagnostic logger > contains setup and close failure of one owner channel`
- `bun|src/project-run/diagnostic-logging/logger.test.ts|Project Run diagnostic logger > summarizes descriptor-safe normal values without rendering their full lifecycle payload`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-start.test.ts|Package Run diagnostic logging output > writes one compact invocation start instead of catalog entries for every Check`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-data.test.ts|Package Run diagnostic logging output > does not duplicate accepted final data into the core diagnostic channel`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-data.test.ts|Package Run diagnostic logging output > keeps accepted handoff references out of machine and diagnostic publication`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-hostile.test.ts|Package Run diagnostic logging output > does not invoke hostile author details while diagnostic logging is enabled`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-runtime.test.ts|Package Run diagnostic logging output > closes diagnostic logging once after an unexpected nonconfiguration failure`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-failures.test.ts|Package Run diagnostic logging output > isolates a scheduler channel writer failure while retaining core channel evidence and facts`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-failures.test.ts|Package Run diagnostic logging output > closes diagnostic channels before progress after a diagnostic close failure`
- `bun|src/project-run/progress-rendering/invocation-output-failure.test.ts|Package Run output failure composition > continues output publication after a progress writer failure`
- `bun|src/project-run/progress-rendering/invocation-output-failure.test.ts|Package Run output failure composition > keeps both failed outputs and prioritizes progress rendering`
  Proves:

- Disabled diagnostic logging constructs neither directory/file nor writer; its disabled channel readbacks have `null` files without changing progress, publication or Check execution. Only diagnostic logging or machine publication enables one invocation-creation wall-clock capture: machine-only publication serializes it as `invocation.timestamp`; diagnostic-only logging captures it for diagnostic identity and the default UTC-compact filename; when both are enabled they share the same immutable instant; when both are disabled the Run does not read or serialize wall clock.
- By default an enabled log uses explicit core/scheduler owner files with one UTC-compact-time-and-UUID suffix and newline-terminated timeline observations. The router assigns every channel observation one invocation-wide sequence/elapsed/invocation ID header; filterable `[]` tags and semantic `key=value` facts remain bounded physical lines without becoming a parser or versioned format. Its instant is not publication completion time. Scheduler writes one graph plus fingerprint and decisions retain only the fingerprint and dynamic facts. The compact core initial observation reports the Check count without one `catalog.check` projection per normalized Check; `run.terminal-before-log-close` reports that terminal fact is written while diagnostic close remains unconfirmed, and a progress failure does not prevent this independent Product output from closing.
- `check.finished` contains only phase, status, duration and message count; it does not duplicate accepted final data or captured message text. Successful dependency reads retain only producer, status and data presence; a committed Record observation contains `{ checkId, recordId, result }`, while rejected Record reporting remains bounded.
- Accepted `handoff: true` references are not read, summarized or presence-tagged by diagnostic logging. A same-Run dependency consumer can prove strict reference identity while both diagnostic and machine outputs omit its private bytes.
- Diagnostic details use bounded descriptor-only rendering: accessors, `toJSON`, Proxy traps, cyclic/deep/extreme-wide/oversized values and malformed author handoff data cannot execute author hooks or alter Check facts.
- Every non-configuration result path closes each enabled diagnostic channel at most once, including unexpected runtime containment failures. Terminal observation precedes diagnostic close/status merge; the invocation attempts every enabled diagnostic-channel close before it closes an unclosed progress writer, even when a diagnostic close fails. Setup, append/render and close failures are contained per channel, preserve final Check/Record facts, retain aggregate plus per-channel readback, and diagnostic logging is selected only after progress-rendering and machine-publication failure priorities. Public learned helpers use caller-owned observations and do not create a Product diagnostic channel.

## Case WB-RUN-RESULT-CHECK-MESSAGES-001: Final-snapshot Run results retain accepted Check messages

Owner: `docs/development/project-run.md#invocation-and-results`
Entities:

- `bun|src/project-run/check-execution/resolved-checks.test.ts|Package Run direct Check execution > retains supplemental Records independently from a passed final result`
- `bun|src/project-run/check-execution/resolved-checks.execution.test.ts|Package Run direct Check execution > keeps completed lifecycle feedback in settlement order but durations in canonical order`
- `bun|src/project-run/check-execution/task-local-preparation.test.ts|Package Run direct Check execution > runs each independent preparation inside its admitted Task lifecycle`
- `bun|src/project-run/check-execution/task-local-preparation.test.ts|Package Run direct Check execution > blocks success dependents before their preparation and lets observers read the terminal result`
- `bun|src/project-run/check-execution/preparation-cancellation.test.ts|Package Run direct Check execution > passes the invocation signal to admitted preparations and closes cancelled Check Tasks`
- `bun|src/project-run/check-execution/preparation-messages.test.ts|Package Run direct Check execution > canonicalizes continue fallbacks and retains preparation messages through execution settlement`
- `bun|src/project-run/check-facts-record-misuse.test.ts|Package Run Check facts integration > contains invalid callback outcomes and Record misuse in the owning Check`
- `bun|src/project-run/check-facts-aggregation.test.ts|Package Run Check facts integration > derives a default strict aggregate and accepts a synchronous custom aggregate`
- `bun|src/project-run/check-facts-aggregation.test.ts|Package Run Check facts integration > reuses effective flag selection for custom aggregation`
- `bun|src/project-run/progress-rendering/result-priority.test.ts|Package Run progress result priority > mutes ordinary progress events after a settled writer failure while preserving final facts`
  Proves:
- Completed, output failure, and execution-phase-cancelled final-snapshot `RunResult` values expose only accepted detached `{ checkId, level, code, message }` items. Invalid attachments and author results rejected by Record settlement expose no partial messages.
- `checkMessages` preserves author order within each Check and canonical snapshot Check order across parallel settlement; disabling progress or a settled progress writer failure does not remove it.
- Task-local preparation receives the invocation signal only after admission; cooperative cancellation closes the existing execution phase as `cancelled` without admitting pending author work.
- A real Run preserves policy-enabled Check Records, dependent admission, aggregation, canonical durations and machine-v4 facts while returning accepted messages separately; validated machine bytes and models contain neither messages nor the quiet-pass presentation policy. The default and custom aggregation consume the invocation's private effective flag selection, including activated prerequisites, without projecting that selection into the result.

## Case ADD-SECRET-DETECTION-AUTHORING-001: Secret detection requires an explicit closed files policy

Owner: `docs/checks/secret-detection.md#参数与默认配置`
Entities:

- `bun|src/package-checks/secret-detection/secret-detection.test.ts|secretDetection > requires a complete explicit files policy and publishes the public parser`

Proves:

- `secretDetection` rejects missing or partial files authoring, freezes only its closed resource/waiver options, and exposes a parser that verifies the five safe final-count invariants.

## Case WB-DIAGNOSTIC-FILE-NAMING-001: Invocation controls opt into channel-only filenames without weakening writer safety

Owner: `docs/development/project-run.md#diagnostic-file-naming`
Entities:

- `bun|src/project-run/progress-rendering/invocation-diagnostic-naming.test.ts|Package Run diagnostic file naming > rejects unsupported naming before author work while preserving optional controls`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-naming.test.ts|Package Run diagnostic file naming > keeps unique defaults and selects fixed channel names without changing identity or disabled output`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-naming.test.ts|Package Run diagnostic file naming > refuses concurrent and repeated channel targets without overwriting existing logs or facts`
- `bun|src/project-run/progress-rendering/invocation-diagnostic-naming.test.ts|Package Run diagnostic file naming > reports a single channel collision with its real target while the other channel succeeds`
  Proves:

- Only omitted/undefined, `unique` and `channel` controls are accepted; invalid values fail before author work, valid controls are frozen, and undefined is omitted from the snapshot.
- Default and explicit unique modes preserve UTC/UUID basenames; channel mode selects only `core.log` / `scheduler.log`, preserves invocation correlation and Definition fingerprint, and does not enable disabled diagnostics or create their directory.
- Concurrent and repeated channel targets fail without overwriting or appending existing bytes, while settled Check facts survive. A pre-existing core file fails only that channel, retains its real target readback, allows scheduler success and produces aggregate diagnostic failure; no pair-atomic rollback is promised.

## Case SCAN-CONFIG-MARKDOWN-LINT: 闭合 Markdown lint policy

Owner: `docs/checks/markdown-lint.md#参数与默认配置`
Entities:

- `bun|src/package-checks/markdown-lint/default-check.test.ts|Markdown lint Check > materializes the closed recommended policy and rejects malformed authoring`
  Proves:
- `markdownLint(options?)` materializes the eight recommended Product rules, default advisory policy, disabled cache and frozen empty waiver list, exposes its final-data parser, and rejects empty, duplicate, unknown or invalid-cache authoring fields before execution.

## Case SCAN-CONFIG-MARKDOWN-LINT-WAIVERS: Markdown lint 精确 waiver 的闭合安全 authoring

Owner: `docs/checks/markdown-lint.md#精确-finding-waiver`
Entities:

- `bun|src/package-checks/markdown-lint/finding-waiver-authoring.test.ts|Markdown lint waiver authoring > snapshots closed full-range identities and keeps resolved waivers deeply frozen`
- `bun|src/package-checks/markdown-lint/finding-waiver-authoring.test.ts|Markdown lint waiver authoring > rejects malformed ranges, noncanonical paths, duplicate identities and hostile authoring`

Proves:

- 精确 waiver 接受完整 public rule catalog、规范 root-relative path 和同行正安全位置，包括 point range；resolved 数组、waiver、identity、range 与两端位置均独立冻结，调用方后续修改不改变配置。
- 未知字段、缺少位置、倒置或跨行 range、非法位置或路径、空 reason、重复结构 identity、稀疏数组、特殊属性及 hostile accessor/proxy 被闭合边界拒绝；不调用 getter，非法 resolved waiver 在读取 source 前结算为 `invalid-options`。

## Case API-CONTEXT-CALLBACK-AUTHORING-001: Context declarations preserve phase-selected business callback types

Owner: `docs/api-mechanics.md#声明与类型`
Entities:

- `bun|src/package-tools/context-callback/define-context-callback.test.ts|preserves business input and selected context types across callback phases`
  Proves:

- `defineContextCallback` preserves descriptor identity and business input/result inference for all seven phases; exact selected fields, empty defaults, phase restrictions, synchronous decisions and conservative widened/union demand are checked by the paired TypeScript acceptance evidence. Check preparation conversion, typed final data and provider handoff remain assignable through `defineCheck`.
