/** Maps normalized Checks into the Scheduler's opaque Task execute contract. */

import type { NormalizedCheck } from "../../project-definition/project-definition.ts";
import {
  runPreparedTaskGraph,
  type PreparedTaskGraphRunOptions
} from "../task-scheduler/scheduler.ts";
import {
  CheckExecutionInvariantFailure,
  type CheckExecutionState
} from "./execution-settlement.ts";
import { settleBlockedDependent, trustedFailure } from "./execution-finalization.ts";
import type { FlagControlSettlement } from "./flag-controls.ts";
import type { ExecutableTaskGraph } from "../task-scheduler/graph.ts";
import {
  executeAdmittedCheck,
  type AdmittedCheckExecutionInput,
  type CheckExecutionClock
} from "./admitted-check-execution.ts";
import type { PreparedCheckExecutionInput } from "./resolved-checks.ts";

const INERT_SIGNAL = new AbortController().signal;
const DIRECT_EXECUTION_INVOCATION_ID = "invocation/v1:direct-check-execution";
const SYSTEM_MONOTONIC_CLOCK: CheckExecutionClock = Object.freeze({
  now: () => performance.now()
});

export async function runScheduledChecks(
  input: Readonly<{
    readonly execution: PreparedCheckExecutionInput & {
      readonly checks: readonly NormalizedCheck[];
    };
    readonly taskGraph: ExecutableTaskGraph;
    readonly flagControlSettlements: readonly FlagControlSettlement[];
    readonly state: CheckExecutionState;
  }>
): Promise<Awaited<ReturnType<typeof runPreparedTaskGraph<boolean>>>> {
  try {
    return await runPreparedTaskGraph(input.taskGraph, schedulerOptionsFor(input));
  } catch (error) {
    throw trustedFailure(error);
  }
}

function schedulerOptionsFor(
  input: Readonly<{
    readonly execution: PreparedCheckExecutionInput & {
      readonly checks: readonly NormalizedCheck[];
    };
    readonly taskGraph: ExecutableTaskGraph;
    readonly flagControlSettlements: readonly FlagControlSettlement[];
    readonly state: CheckExecutionState;
  }>
): PreparedTaskGraphRunOptions<boolean> {
  const execution = input.execution;
  const checksByCheckId = new Map(
    execution.checks.map((check) => [check.definition.checkId, check] as const)
  );
  const schedulerDiagnosticLogger =
    execution.schedulerDiagnosticLoggingEnabled === false
      ? undefined
      : (execution.schedulerDiagnosticLogger ?? execution.diagnosticLogger);
  return {
    ...(execution.admissionPolicy === undefined
      ? {}
      : { admissionPolicy: execution.admissionPolicy }),
    ...(schedulerDiagnosticLogger === undefined
      ? {}
      : { diagnosticLogger: schedulerDiagnosticLogger }),
    ...(execution.schedulerPerformanceDiagnostics === undefined
      ? {}
      : { performanceDiagnostics: execution.schedulerPerformanceDiagnostics }),
    ...(execution.schedulerTerminalContextNeeds === undefined
      ? {}
      : { terminalContextNeeds: execution.schedulerTerminalContextNeeds }),
    ...(execution.schedulerTerminalEffects === undefined
      ? {}
      : { terminalEffects: execution.schedulerTerminalEffects }),
    ...(execution.onSchedulerTerminalEffectFailure === undefined
      ? {}
      : { onTerminalEffectFailure: execution.onSchedulerTerminalEffectFailure }),
    ...(execution.onSchedulerTerminalEffectsSettled === undefined
      ? {}
      : { onTerminalEffectsSettled: execution.onSchedulerTerminalEffectsSettled }),
    preAdmissionTaskResults: Object.freeze(
      input.flagControlSettlements.map((settlement) =>
        Object.freeze({ taskId: settlement.check.definition.checkId, value: false })
      )
    ),
    ...(execution.signal === undefined ? {} : { signal: execution.signal }),
    isPrerequisiteSatisfied: (satisfied) => satisfied,
    onTaskBlocked: (task, dependencyIds) => {
      settleBlockedDependent({
        check: requiredNormalizedCheck(checksByCheckId, task, "Blocked Task"),
        dependencyIds,
        state: input.state
      });
    },
    execute: (task, context) =>
      executeAdmittedCheck({
        ...input.state,
        ...admittedExecutionFacts(execution),
        check: requiredNormalizedCheck(checksByCheckId, task, "Task graph"),
        signal: context.signal ?? INERT_SIGNAL
      })
  };
}

function requiredNormalizedCheck(
  checksByCheckId: ReadonlyMap<string, NormalizedCheck>,
  task: Readonly<{ readonly id: string }>,
  owner: "Blocked Task" | "Task graph"
): NormalizedCheck {
  const check = checksByCheckId.get(task.id);
  if (check === undefined) {
    throw new CheckExecutionInvariantFailure(`${owner} has no normalized Check`);
  }
  return check;
}

function admittedExecutionFacts(
  execution: PreparedCheckExecutionInput
): Omit<AdmittedCheckExecutionInput, keyof CheckExecutionState | "check" | "signal"> {
  return {
    clock: execution.clock ?? SYSTEM_MONOTONIC_CLOCK,
    onAdmittedCheck: execution.onAdmittedCheck,
    invocationId: execution.invocationId ?? DIRECT_EXECUTION_INVOCATION_ID,
    paths: execution.paths,
    project: execution.project
  };
}
