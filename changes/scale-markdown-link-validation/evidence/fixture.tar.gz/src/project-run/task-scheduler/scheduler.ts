import { prepareExecutableTaskGraph, type ExecutableTaskGraph } from "./graph.ts";
import {
  decideSchedulerFromCore,
  type SchedulerDecision,
  type SchedulerTrigger
} from "./scheduler-decision.ts";
import {
  type RunTaskGraphOptions,
  type SchedulerState,
  type TaskGraphRun
} from "./execution-state.ts";
export type {
  RunTaskGraphOptions,
  SettledTask,
  TaskExecutionContext,
  TaskGraphRun,
  TaskSettlement
} from "./execution-state.ts";
import { AdmissionPolicyFault } from "./scheduler-admission-decision.ts";
import { replayCoreForcedBlocks } from "./forced-block-effect-replay.ts";
import {
  observeAdmissionPolicyFault,
  observeSchedulerDecision,
  performanceState
} from "./scheduler-observation.ts";
import { observeTerminalMeasurement } from "./scheduler-terminal-measurement.ts";
import {
  createObservedSchedulerState,
  decisionBoundaryMeasurement
} from "./scheduler-observation-setup.ts";
import {
  applyAdmission,
  applyAdmissionPolicyFault,
  applyBlockedSettlement,
  applyCancellation,
  buildTaskGraphRun,
  nextRunningSettlement,
  settleRunningTask
} from "./scheduler-task-lifecycle.ts";
import {
  cancelPendingAdmissionCore,
  reconcileAdmissionCore,
  selectAdmissionCore,
  settleRunningAdmissionCore,
  type AdmissionCoreEffect
} from "./admission-core/core.ts";

export async function runTaskGraph<TResult>(
  options: RunTaskGraphOptions<TResult>
): Promise<TaskGraphRun<TResult>> {
  return runPreparedTaskGraph(
    prepareExecutableTaskGraph(options.graph, options.maxParallel),
    options
  );
}

export type PreparedTaskGraphRunOptions<TResult> = Omit<
  RunTaskGraphOptions<TResult>,
  "graph" | "maxParallel"
>;

/** Executes a private validated graph; cap and static metadata cannot be supplied independently. */
export async function runPreparedTaskGraph<TResult>(
  prepared: ExecutableTaskGraph,
  input: PreparedTaskGraphRunOptions<TResult>
): Promise<TaskGraphRun<TResult>> {
  const { state, options, terminalPlan, diagnostics } = createObservedSchedulerState(
    prepared,
    input
  );
  const initialReconciliation = reconcileAdmissionCore(state.admissionCore);
  replayCoreForcedBlocks(
    state,
    initialReconciliation.effects,
    initialReconciliation.effectStates,
    diagnostics,
    triggerForInitialReconciliation()
  );
  let trigger: SchedulerTrigger = Object.freeze({ kind: "execution-started" });

  while (true) {
    let decision: SchedulerDecision;
    try {
      const runtime = Object.freeze({
        isAbortRequested: state.signal?.aborted === true,
        isCancelled: state.isCancelled
      });
      const measurement =
        state.admissionPolicy.requiresMeasurement === true
          ? () => decisionBoundaryMeasurement(diagnostics)
          : undefined;
      const decide = () =>
        decideSchedulerFromCore({
          admissionCore: state.admissionCore,
          policy: state.admissionPolicy,
          runtime,
          trigger,
          ...(measurement === undefined ? {} : { measurement })
        });
      decision = diagnostics?.measureControlPath(decide) ?? decide();
    } catch (error) {
      if (!(error instanceof AdmissionPolicyFault)) throw error;
      const cancellation = cancelPendingAdmissionCore(state.admissionCore);
      state.admissionCore = cancellation.state;
      diagnostics?.beforePendingSettlement([...state.pending.keys()]);
      if (diagnostics === undefined) applyAdmissionPolicyFault(state, error);
      else
        diagnostics.measureControlPath(() => {
          applyAdmissionPolicyFault(state, error);
        });
      diagnostics?.captureState(performanceState(state));
      observeAdmissionPolicyFault(state, error);
      trigger = Object.freeze({ kind: "cancellation-applied" });
      continue;
    }
    observeSchedulerDecision(state, decision, diagnostics);

    switch (decision.kind) {
      case "admit": {
        if (state.signal?.aborted === true) {
          const cancellation = cancelPendingAdmissionCore(state.admissionCore);
          state.admissionCore = cancellation.state;
          diagnostics?.beforePendingSettlement([...state.pending.keys()]);
          const lifecycleFault = new AdmissionPolicyFault("lifecycle-invalid-select");
          if (diagnostics === undefined) applyAdmissionPolicyFault(state, lifecycleFault);
          else
            diagnostics.measureControlPath(() => {
              applyAdmissionPolicyFault(state, lifecycleFault);
            });
          diagnostics?.captureState(performanceState(state));
          observeAdmissionPolicyFault(state, lifecycleFault);
          trigger = Object.freeze({ kind: "cancellation-applied" });
          continue;
        }
        const selection = selectAdmissionCore(state.admissionCore, decision.taskId);
        if (!selection.accepted) {
          throw new Error("shared admission core rejected a Scheduler hard-guarded selection");
        }
        const admissionEffect = selection.transition.effects[0];
        if (admissionEffect === undefined) {
          throw new Error("shared admission core omitted a Scheduler admission effect");
        }
        state.admissionCore = selection.transition.state;
        diagnostics?.beforeAdmission(decision.taskId, () => [...state.runningById.keys()]);
        if (diagnostics === undefined) applyAdmission(state, decision);
        else
          diagnostics.measureControlPath(() => {
            applyAdmission(state, decision);
          });
        diagnostics?.captureState(performanceState(state));
        if (state.admissionPolicy.requiresMeasurement === true) {
          diagnostics?.beginSelectedPolicyAction(decision.taskId);
          diagnostics?.recordEffect(Object.freeze({ kind: "admitted", taskId: decision.taskId }));
        }
        observeAdmissionCoreEffect(state, admissionEffect);
        trigger = Object.freeze({ kind: "admission-continued" });
        continue;
      }
      case "settle-blocked":
        diagnostics?.beforePendingSettlement([decision.taskId]);
        if (diagnostics === undefined) applyBlockedSettlement(state, decision);
        else
          diagnostics.measureControlPath(() => {
            applyBlockedSettlement(state, decision);
          });
        diagnostics?.captureState(performanceState(state));
        diagnostics?.recordEffect(
          Object.freeze({
            kind: "settled",
            settlementKind: "blocked",
            taskId: decision.taskId
          })
        );
        trigger = Object.freeze({
          kind: "blocked-settled",
          taskId: decision.taskId
        });
        continue;
      case "cancel-pending":
        state.admissionCore = cancelPendingAdmissionCore(state.admissionCore).state;
        diagnostics?.beforePendingSettlement(decision.taskIds);
        if (diagnostics === undefined) applyCancellation(state, decision);
        else
          diagnostics.measureControlPath(() => {
            applyCancellation(state, decision);
          });
        diagnostics?.captureState(performanceState(state));
        for (const taskId of decision.taskIds) {
          diagnostics?.recordEffect(
            Object.freeze({
              kind: "settled",
              settlementKind: "cancelled-before-start",
              taskId
            })
          );
        }
        trigger = Object.freeze({ kind: "cancellation-applied" });
        continue;
      case "await-running": {
        if (decision.proposal?.kind === "wait") {
          diagnostics?.beforeAcceptedWait();
          if (state.admissionPolicy.requiresMeasurement === true) {
            diagnostics?.beginWaitPolicyAction();
          }
        }
        const completion = await nextRunningSettlement(state);
        diagnostics?.beforeRunningSettlement(completion.taskId);
        if (diagnostics === undefined) settleRunningTask(state, completion);
        else
          diagnostics.measureControlPath(() => {
            settleRunningTask(state, completion);
          });
        const settlementKind = completion.settlement.kind;
        if (
          settlementKind !== "completed" &&
          settlementKind !== "prerequisite-unsatisfied" &&
          settlementKind !== "failed"
        ) {
          throw new Error("running Task completed with a non-running settlement kind");
        }
        const transition = settleRunningAdmissionCore(
          state.admissionCore,
          completion.taskId,
          settlementKind
        );
        if (!transition.accepted) {
          throw new Error("shared admission core rejected a Scheduler running settlement");
        }
        const directEffect = transition.transition.effects[0];
        const directState = transition.transition.effectStates[0];
        if (directEffect === undefined || directState === undefined) {
          throw new Error("shared admission core omitted a Scheduler running settlement effect");
        }
        state.admissionCore = directState;
        diagnostics?.captureState(performanceState(state));
        diagnostics?.recordEffect(
          Object.freeze({
            kind: "settled",
            settlementKind: completion.settlement.kind,
            taskId: completion.taskId
          })
        );
        observeAdmissionCoreEffect(state, directEffect);
        replayCoreForcedBlocks(
          state,
          transition.transition.effects.slice(1),
          transition.transition.effectStates.slice(1),
          diagnostics,
          Object.freeze({
            kind: "task-settled",
            settlementKind: completion.settlement.kind,
            taskId: completion.taskId
          })
        );
        trigger = Object.freeze({
          kind: "task-settled",
          settlementKind: completion.settlement.kind,
          taskId: completion.taskId
        });
        continue;
      }
      case "complete": {
        const run =
          diagnostics?.measureControlPath(() => buildTaskGraphRun(state)) ??
          buildTaskGraphRun(state);
        const terminalContext = await observeTerminalMeasurement({
          plan: terminalPlan,
          diagnostics,
          options,
          state
        });
        return Object.freeze({
          ...run,
          ...(terminalContext === undefined ? {} : { terminalContext })
        });
      }
    }
  }
}

function observeAdmissionCoreEffect<TResult>(
  state: SchedulerState<TResult>,
  effect: AdmissionCoreEffect
): void {
  if (state.onAdmissionCoreEffect === undefined) return;
  state.onAdmissionCoreEffect(Object.freeze({ effect, state: state.admissionCore }));
}

function triggerForInitialReconciliation(): SchedulerTrigger {
  return Object.freeze({ kind: "execution-started" });
}
