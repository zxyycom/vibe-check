import type { PlannedTask } from "./graph.ts";
import {
  cancelPendingTasks,
  recordSettlement,
  type RunningTaskCompletion,
  type RunTaskGraphOptions,
  type SchedulerState,
  type TaskGraphRun,
  type TaskSettlement
} from "./execution-state.ts";
import type { SchedulerDecision } from "./scheduler-decision.ts";
import type { AdmissionPolicyFault } from "./scheduler-admission-decision.ts";

export function applyAdmissionPolicyFault<TResult>(
  state: SchedulerState<TResult>,
  fault: AdmissionPolicyFault
): void {
  if (state.admissionPolicyFault !== undefined) {
    throw new Error("scheduler received more than one admission policy fault");
  }
  state.admissionPolicyFault = fault.category;
  cancelPendingTasks(state);
}

export function applyAdmission<TResult>(
  state: SchedulerState<TResult>,
  decision: Extract<SchedulerDecision, { readonly kind: "admit" }>
): void {
  const task = takePendingTask(state, decision.taskId, "admission");

  const completion = Promise.resolve()
    .then(() => state.execute(task, Object.freeze({ signal: state.signal })))
    .then((value) => completedTaskCompletion(task.id, value, state.isPrerequisiteSatisfied))
    .catch((error: unknown) => failedTaskCompletion<TResult>(task.id, error));
  state.runningById.set(task.id, { task, completion });
  state.admissionFacts?.recordAdmission(task.id);
}

export function applyBlockedSettlement<TResult>(
  state: SchedulerState<TResult>,
  decision: Extract<SchedulerDecision, { readonly kind: "settle-blocked" }>
): void {
  applyForcedBlockedSettlement(state, decision.taskId, decision.dependencyIds);
}

/** Applies one canonical private forced-block effect after the shared reducer selected it. */
export function applyForcedBlockedSettlement<TResult>(
  state: SchedulerState<TResult>,
  taskId: string,
  dependencyIds: readonly string[]
): void {
  const task = takePendingTask(state, taskId, "blocked settlement");
  recordSettlement(
    state,
    task,
    Object.freeze({ kind: "blocked", dependencyIds: Object.freeze([...dependencyIds]) })
  );
  state.onTaskBlocked?.(task, dependencyIds);
}

export function applyCancellation<TResult>(
  state: SchedulerState<TResult>,
  decision: Extract<SchedulerDecision, { readonly kind: "cancel-pending" }>
): void {
  const pendingTaskIds = [...state.pending.keys()];
  if (!sameTaskIds(pendingTaskIds, decision.taskIds)) {
    throw new Error("scheduler cancellation decision no longer matches pending tasks");
  }
  cancelPendingTasks(state);
}

export async function nextRunningSettlement<TResult>(
  state: SchedulerState<TResult>
): Promise<RunningTaskCompletion<TResult>> {
  if (state.runningById.size === 0) {
    throw new Error("scheduler cannot await a task when no task is running");
  }
  return Promise.race([...state.runningById.values()].map((running) => running.completion));
}

export function settleRunningTask<TResult>(
  state: SchedulerState<TResult>,
  result: RunningTaskCompletion<TResult>
): void {
  const running = state.runningById.get(result.taskId);
  if (running === undefined) throw new Error(`task ${result.taskId} settled without admission`);
  state.runningById.delete(result.taskId);
  recordSettlement(state, running.task, result.settlement);
}

export function buildTaskGraphRun<TResult>(state: SchedulerState<TResult>): TaskGraphRun<TResult> {
  return Object.freeze({
    admissionPolicyFault: state.admissionPolicyFault,
    cancelled: state.isCancelled,
    settlements: Object.freeze(
      state.graph.tasks.map((task) => {
        const settlement = state.settlementsByTaskId.get(task.id);
        if (settlement === undefined) throw new Error(`task ${task.id} was not settled`);
        return Object.freeze({ task, settlement });
      })
    )
  });
}

function takePendingTask<TResult>(
  state: SchedulerState<TResult>,
  taskId: string,
  action: string
): PlannedTask {
  const task = state.pending.get(taskId);
  if (task === undefined) throw new Error(`task ${taskId} is not pending for ${action}`);
  state.pending.delete(taskId);
  return task;
}

function completedTaskCompletion<TResult>(
  taskId: string,
  value: TResult,
  isPrerequisiteSatisfied: RunTaskGraphOptions<TResult>["isPrerequisiteSatisfied"]
): RunningTaskCompletion<TResult> {
  const settlement: TaskSettlement<TResult> =
    isPrerequisiteSatisfied?.(value) === false
      ? { kind: "prerequisite-unsatisfied", value }
      : { kind: "completed", value };
  return Object.freeze({ taskId, settlement: Object.freeze(settlement) });
}

function failedTaskCompletion<TResult>(
  taskId: string,
  error: unknown
): RunningTaskCompletion<TResult> {
  const settlement: TaskSettlement<TResult> = { kind: "failed", error };
  return Object.freeze({ taskId, settlement: Object.freeze(settlement) });
}

function sameTaskIds(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((taskId, index) => taskId === right[index]);
}
