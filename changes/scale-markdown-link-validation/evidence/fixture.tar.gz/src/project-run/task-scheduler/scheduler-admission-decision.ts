import { staticAdmissionSelectionPolicy } from "./admission-selection-policy.ts";
import { staticAdmissionCandidateForCore } from "./admission-core/static-selection-query.ts";
import type { AdmissionPolicyContext } from "../../project-definition/project-definition.ts";
import type {
  AdmissionCandidate,
  AdmissionPolicyDecision,
  AdmissionSelectionPolicy
} from "./admission-selection-policy.ts";
import {
  freezeDecisionWithContext,
  type SchedulerAdmissionCandidateFact,
  type SchedulerAdmissionHardGuard,
  type SchedulerDecision,
  type SchedulerDecisionContext,
  type SchedulerTrigger
} from "./scheduler-decision-model.ts";
import type { SchedulerInspection } from "./scheduler-decision-inspection.ts";
import {
  admissionCandidatesForCore,
  scopeToActivateForCore,
  type AdmissionCoreState
} from "./admission-core/core.ts";

export interface SchedulerDecisionCycle {
  readonly admissionCore: AdmissionCoreState;
  readonly context: SchedulerDecisionContext;
  readonly policy: AdmissionSelectionPolicy;
  /** Invoked immediately before the private policy seam enters a custom callback. */
  readonly measurement?: () => Readonly<
    Partial<Pick<AdmissionPolicyContext, "cumulative" | "actionHistory">>
  >;
  readonly state: SchedulerInspection;
  readonly runtime: Pick<SchedulerInspection, "isAbortRequested" | "isCancelled">;
  readonly trigger: SchedulerTrigger;
}

export function decideAdmission(cycle: SchedulerDecisionCycle): SchedulerDecision {
  if (cycle.policy === staticAdmissionSelectionPolicy) return decideStaticAdmission(cycle);
  const candidates = admissionCandidatesForCore(cycle.admissionCore);
  if (candidates.length === 0) return awaitDecision(cycle, candidates);

  const measurement = cycle.measurement?.();
  const result = validatePolicyDecision(
    cycle.policy.decide(
      Object.freeze({
        admissionCore: cycle.admissionCore,
        runtime: cycle.runtime,
        candidates,
        graph: cycle.admissionCore.compiled.graph,
        get graphSnapshot() {
          return cycle.context.graphIdentity;
        },
        get inspection() {
          return cycle.state;
        },
        ...(measurement === undefined ? {} : { measurement })
      })
    )
  );
  return result.kind === "select"
    ? admitDecision(cycle, candidates, result)
    : awaitDecision(cycle, candidates, result);
}

/** Static execution consumes group heads; full boundary facts remain detached and demand-driven. */
function decideStaticAdmission(cycle: SchedulerDecisionCycle): SchedulerDecision {
  const capturedCore = cycle.admissionCore;
  const candidate = staticAdmissionCandidateForCore(capturedCore);
  let projectedCandidates: readonly AdmissionCandidate[] | undefined;
  const candidates = () => (projectedCandidates ??= admissionCandidatesForCore(capturedCore));
  const projectCandidateFacts = () => candidateFacts(candidates());
  const projectEligibleCount = () => candidates().length;
  if (candidate?.canAdmit === true) {
    const proposal = Object.freeze({ kind: "select" as const, taskId: candidate.task.id });
    return freezeDecisionWithContext(
      cycle.context,
      {
        admissionPriority: candidate.task.admissionPriority,
        candidates: Object.freeze([]),
        eligibleCount: 0,
        hardGuard: selectHardGuard(candidate.task.id),
        kind: "admit",
        proposal,
        scopeToActivate: scopeToActivateForCore(capturedCore, candidate.task.id),
        taskId: candidate.task.id,
        trigger: cycle.trigger
      },
      projectCandidateFacts,
      projectEligibleCount
    );
  }
  if (capturedCore.selection.memberships.status.running.size === 0)
    throw new AdmissionPolicyFault("undrainable-wait");
  return freezeDecisionWithContext(
    cycle.context,
    {
      candidates: Object.freeze([]),
      eligibleCount: 0,
      hardGuard: waitHardGuard(),
      kind: "await-running",
      proposal: candidate === undefined ? null : Object.freeze({ kind: "wait" }),
      trigger: cycle.trigger
    },
    projectCandidateFacts,
    projectEligibleCount
  );
}

function admitDecision(
  cycle: SchedulerDecisionCycle,
  candidates: readonly AdmissionCandidate[],
  result: Extract<AdmissionPolicyDecision, { readonly kind: "select" }>
): SchedulerDecision {
  const candidate = candidateFor(result.taskId, candidates);
  if (candidate === undefined) {
    throw new AdmissionPolicyFault("non-candidate-select");
  }
  if (!candidate.canAdmit) {
    throw new AdmissionPolicyFault("capacity-invalid-select");
  }
  return freezeDecisionWithContext(
    cycle.context,
    {
      admissionPriority: candidate.task.admissionPriority,
      candidates: Object.freeze([]),
      eligibleCount: candidates.length,
      hardGuard: selectHardGuard(candidate.task.id),
      kind: "admit",
      proposal: result,
      scopeToActivate: scopeToActivateForCore(cycle.admissionCore, candidate.task.id),
      taskId: candidate.task.id,
      trigger: cycle.trigger
    },
    () => candidateFacts(candidates)
  );
}

function awaitDecision(
  cycle: SchedulerDecisionCycle,
  candidates: readonly AdmissionCandidate[],
  proposal: AdmissionPolicyDecision | null = null
): SchedulerDecision {
  if (cycle.admissionCore.selection.memberships.status.running.size === 0) {
    throw new AdmissionPolicyFault("undrainable-wait");
  }
  return freezeDecisionWithContext(
    cycle.context,
    {
      candidates: Object.freeze([]),
      eligibleCount: candidates.length,
      hardGuard: waitHardGuard(),
      kind: "await-running",
      proposal,
      trigger: cycle.trigger
    },
    () => candidateFacts(candidates)
  );
}

function candidateFacts(
  candidates: readonly AdmissionCandidate[]
): readonly SchedulerAdmissionCandidateFact[] {
  return Object.freeze(
    candidates.map((candidate) =>
      Object.freeze({ canAdmit: candidate.canAdmit, taskId: candidate.task.id })
    )
  );
}

function selectHardGuard(
  taskId: string
): Extract<SchedulerAdmissionHardGuard, { readonly kind: "select" }> {
  return Object.freeze({
    canAdmit: true,
    isCandidate: true,
    kind: "select",
    lifecycleOpen: true,
    taskId
  });
}

function waitHardGuard(): Extract<SchedulerAdmissionHardGuard, { readonly kind: "wait" }> {
  return Object.freeze({ kind: "wait", runningCanDrain: true });
}

function validatePolicyDecision(value: unknown): AdmissionPolicyDecision {
  if (!isRecord(value)) throw new AdmissionPolicyFault("malformed-proposal");
  if (value["kind"] === "select") {
    requireExactKeys(value, ["kind", "taskId"]);
    if (typeof value["taskId"] !== "string") {
      throw new AdmissionPolicyFault("malformed-proposal");
    }
    return Object.freeze({ kind: "select", taskId: value["taskId"] });
  }
  if (value["kind"] === "wait") {
    requireExactKeys(value, ["kind"]);
    return Object.freeze({ kind: "wait" });
  }
  throw new AdmissionPolicyFault("malformed-proposal");
}

function candidateFor(
  taskId: string,
  candidates: readonly AdmissionCandidate[]
): AdmissionCandidate | undefined {
  return candidates.find((candidate) => candidate.task.id === taskId);
}

function requireExactKeys(value: Readonly<Record<string, unknown>>, keys: readonly string[]): void {
  const prototype = Reflect.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    throw new AdmissionPolicyFault("malformed-proposal");
  }
  const actualKeys = Reflect.ownKeys(value);
  if (
    actualKeys.length !== keys.length ||
    actualKeys.some((key) => typeof key !== "string" || !keys.includes(key))
  ) {
    throw new AdmissionPolicyFault("malformed-proposal");
  }
}

function isRecord(value: unknown): value is Readonly<Record<string, unknown>> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

export type AdmissionPolicyFaultCategory =
  | "callback-threw"
  | "thenable-proposal"
  | "malformed-proposal"
  | "non-candidate-select"
  | "capacity-invalid-select"
  | "lifecycle-invalid-select"
  | "undrainable-wait";

export class AdmissionPolicyFault extends Error {
  public readonly category: AdmissionPolicyFaultCategory;

  public constructor(category: AdmissionPolicyFaultCategory) {
    super("admission policy fault");
    this.category = category;
  }
}
