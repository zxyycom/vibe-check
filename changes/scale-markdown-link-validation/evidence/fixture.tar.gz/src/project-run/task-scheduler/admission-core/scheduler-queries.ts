import type { AdmissionPolicyContext } from "../../../project-definition/scheduler-policy.ts";
import type { AdmissionCoreState } from "./selection.ts";
import {
  activeScopesForCore,
  effectiveMaxParallelForCore,
  taskSlotsForCore,
  requiredTaskForCore
} from "./state-query.ts";

/** Thin authoritative queries; none constructs a Scheduler inspection or another state index. */
export function capacityForCore(core: AdmissionCoreState): AdmissionPolicyContext["capacity"] {
  return Object.freeze({
    effectiveMaxParallel: effectiveMaxParallelForCore(core),
    maxParallel: core.compiled.maxParallel,
    running: core.selection.memberships.status.running.size
  });
}

export function activeScopeIdsForCore(core: AdmissionCoreState): readonly string[] {
  return Object.freeze(activeScopesForCore(core).map((scope) => scope.id));
}

export function taskIdsForCore(
  core: AdmissionCoreState,
  kind: "pending" | "running" | "settled"
): readonly string[] {
  return Object.freeze(
    taskSlotsForCore(core, kind).map((slot) => requiredTaskForCore(core, slot).id)
  );
}
