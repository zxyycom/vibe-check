import { createHash } from "node:crypto";

import type { AdmissionPolicy, DeclarativeSchedulerPolicy } from "./scheduler-policy.ts";
import type {
  DeclarativeProjectOutputs,
  DeclarativeProjectSnapshot,
  NormalizedCheck,
  ProjectDefinition
} from "./project-definition.ts";
import { resolveProgressRenderingOutput } from "./output-defaults.ts";
import { isNonArrayRecord } from "../data-boundary/value-shapes.ts";
import type { NormalizedProjectChangesConfiguration } from "./project-changes.ts";

/**
 * Produces the immutable, callback-free Definition identity consumed by fingerprinting.
 */
export function createDeclarativeProjectSnapshot(
  definition: Omit<ProjectDefinition, "changes" | "checks"> & {
    readonly changes?: NormalizedProjectChangesConfiguration;
  },
  checks: readonly NormalizedCheck[]
): DeclarativeProjectSnapshot {
  const declarations = checks
    .map(
      ({ execute: _execution, handoff: _handoff, prepare: _preparation, ...declaration }) =>
        declaration
    )
    .sort((left, right) => compareText(left.definition.checkId, right.definition.checkId));
  return deepFreeze({
    apiVersion: definition.apiVersion,
    checks: declarations,
    ...(definition.changes === undefined ? {} : { changes: definition.changes }),
    outputs: declarativeOutputs(definition),
    scheduler: Object.freeze({
      admissionPolicy: declarativeAdmissionPolicy(definition.scheduler.admissionPolicy),
      maxParallel: definition.scheduler.maxParallel,
      resourceCapacities: definition.scheduler.resourceCapacities
    })
  });
}

function declarativeOutputs(
  definition: Pick<ProjectDefinition, "outputs">
): DeclarativeProjectOutputs {
  const progressRendering = resolveProgressRenderingOutput(definition.outputs.progressRendering);
  return Object.freeze({
    diagnosticLogging: definition.outputs.diagnosticLogging,
    machinePublication: definition.outputs.machinePublication,
    progressRendering: Object.freeze({
      enabled: progressRendering.enabled,
      formatter: progressRendering.formatter === null ? "default" : "custom",
      messagePreviewLimit: progressRendering.messagePreviewLimit,
      recordPreviewLimit: progressRendering.recordPreviewLimit,
      textPreviewCodePointLimit: progressRendering.textPreviewCodePointLimit
    })
  });
}

/** Generates the stable SHA-256 fingerprint for one declarative Definition snapshot. */
export function createDeclarativeFingerprint(snapshot: DeclarativeProjectSnapshot): string {
  return createHash("sha256").update(stableJson(snapshot)).digest("hex");
}

function declarativeAdmissionPolicy(
  policy: AdmissionPolicy
): DeclarativeSchedulerPolicy["admissionPolicy"] {
  if (policy.kind === "custom") {
    return Object.freeze({
      kind: "custom" as const,
      strategy: Object.freeze({ kind: policy.strategy.kind })
    });
  }
  return Object.freeze({ kind: "static" as const });
}

function compareText(left: string, right: string): number {
  if (left < right) return -1;
  if (left > right) return 1;
  return 0;
}

function deepFreeze<T>(value: T): T {
  if (typeof value !== "object" || value === null || Object.isFrozen(value)) return value;
  for (const item of Object.values(value)) deepFreeze(item);
  return Object.freeze(value);
}

function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (isNonArrayRecord(value))
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`)
      .join(",")}}`;
  return JSON.stringify(value);
}
