import { existsSync, readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

import type { PackageDocumentationFile } from "../../docs/package-api/check-guides.ts";
import type { PackageMachineMaterial } from "../../docs/machine-artifacts/package-materials.ts";
import { errorMessage } from "../../error-message.ts";
import { isPathWithin } from "../../repository-files/paths.ts";
import { isNonArrayRecord } from "../../value-guards.ts";
import {
  AJV_PACKAGE_NAME,
  JSCPD_PACKAGE_NAME,
  MARKDOWNLINT_PACKAGE_NAME,
  PACKAGE_NAME
} from "../package-contract.ts";
import { runBun, sha256File } from "../pack.ts";
import {
  verifyCandidateRuntimeDependencies,
  type CandidateDependencyProbe
} from "./dependency-probe.ts";
import { assertInstalledCandidateMaterials } from "./installed-materials.ts";
import type { InstalledCandidate } from "./receipt.ts";

interface CandidateInstallationProbe extends CandidateDependencyProbe {
  readonly candidateEntryUrl: string;
}

/** Replaces the dedicated private install and verifies the exact installed package entry. */
export function installCandidate(input: {
  readonly artifactPath: string;
  readonly candidateVersion: string;
  readonly repositoryRoot: string;
  readonly consumerDirectory: string;
  readonly expectedDocuments?: readonly PackageDocumentationFile[];
  readonly expectedJSDocExamplePayloads: readonly string[];
  readonly expectedMachineMaterials?: readonly PackageMachineMaterial[];
  readonly expectedAttributionNotice: Buffer;
  readonly expectedReadme: string;
}): InstalledCandidate {
  const {
    artifactPath,
    candidateVersion,
    repositoryRoot,
    consumerDirectory,
    expectedJSDocExamplePayloads,
    expectedReadme
  } = input;
  const expectedDocuments = input.expectedDocuments ?? [];
  const expectedMachineMaterials = input.expectedMachineMaterials ?? [];
  assertPrivateCandidateConsumer(consumerDirectory);
  // This directory is a dedicated private candidate consumer. Replacing its whole
  // install prevents Bun from satisfying a missing candidate dependency through
  // an ancestor node_modules directory.
  rmSync(join(consumerDirectory, "node_modules"), { force: true, recursive: true });
  runBun({
    args: ["install", "--no-save", "--ignore-scripts", artifactPath],
    cwd: consumerDirectory,
    phase: `install candidate in ${consumerDirectory}`
  });
  return verifyInstallation({
    candidateVersion,
    repositoryRoot,
    consumerDirectory,
    expectedDocuments,
    expectedJSDocExamplePayloads,
    expectedMachineMaterials,
    expectedAttributionNotice: input.expectedAttributionNotice,
    expectedReadme
  });
}

/** Inspects a candidate without accepting an ancestor package or dependency fallback. */
export function inspectInstallation(input: {
  readonly candidateVersion: string;
  readonly repositoryRoot: string;
  readonly consumerDirectory: string;
  readonly expectedDocuments?: readonly PackageDocumentationFile[];
  readonly expectedJSDocExamplePayloads: readonly string[];
  readonly expectedMachineMaterials?: readonly PackageMachineMaterial[];
  readonly expectedAttributionNotice: Buffer;
  readonly expectedReadme: string;
}): InstalledCandidate | undefined {
  try {
    return verifyInstallation(input);
  } catch {
    return undefined;
  }
}

/** Strictly validates a fresh install while retaining every failed validation stage. */
function verifyInstallation(input: {
  readonly candidateVersion: string;
  readonly repositoryRoot: string;
  readonly consumerDirectory: string;
  readonly expectedDocuments?: readonly PackageDocumentationFile[];
  readonly expectedJSDocExamplePayloads: readonly string[];
  readonly expectedMachineMaterials?: readonly PackageMachineMaterial[];
  readonly expectedAttributionNotice: Buffer;
  readonly expectedReadme: string;
}): InstalledCandidate {
  const {
    candidateVersion,
    repositoryRoot,
    consumerDirectory,
    expectedJSDocExamplePayloads,
    expectedReadme
  } = input;
  const expectedDocuments = input.expectedDocuments ?? [];
  const expectedMachineMaterials = input.expectedMachineMaterials ?? [];
  const packageDirectory = join(consumerDirectory, "node_modules", PACKAGE_NAME);
  assertInstalledCandidateManifest(packageDirectory, candidateVersion);
  const probe = probeCandidateInstallation(consumerDirectory);
  const resolvedEntryPath = resolveInstalledCandidateEntry(
    packageDirectory,
    probe.candidateEntryUrl
  );
  assertInstalledCandidateMaterials({
    packageDirectory,
    expectedDocuments,
    expectedMachineMaterials,
    expectedAttributionNotice: input.expectedAttributionNotice,
    expectedJSDocExamplePayloads,
    expectedReadme
  });
  verifyCandidateRuntimeDependencies({
    consumerDirectory,
    packageDirectory,
    repositoryRoot,
    probe
  });
  return Object.freeze({
    installedPackageDirectory: packageDirectory,
    resolvedEntryPath,
    resolvedEntrySha256: sha256File(resolvedEntryPath)
  });
}

function assertInstalledCandidateManifest(
  packageDirectory: string,
  candidateVersion: string
): void {
  const manifestPath = join(packageDirectory, "package.json");
  if (!existsSync(manifestPath))
    throw new Error(`installed candidate package manifest is missing: ${manifestPath}`);
  const manifest = readJsonFile(manifestPath, "installed candidate package manifest");
  if (
    !isNonArrayRecord(manifest) ||
    manifest.name !== PACKAGE_NAME ||
    manifest.version !== candidateVersion
  )
    throw new Error(
      `installed candidate package manifest must declare ${PACKAGE_NAME}@${candidateVersion}: ${manifestPath}`
    );
}

function probeCandidateInstallation(consumerDirectory: string): CandidateInstallationProbe {
  const output = runBun({
    args: candidateInstallationProbeCommand(),
    cwd: consumerDirectory,
    phase: `resolve candidate and dependencies in ${consumerDirectory}`
  });
  return parseCandidateInstallationProbe(output, consumerDirectory);
}

function candidateInstallationProbeCommand(): readonly string[] {
  return [
    "-e",
    `import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
const candidateEntryUrl = import.meta.resolve(process.argv[1]);
const candidateEntryPath = fileURLToPath(candidateEntryUrl);
const requireFromCandidate = createRequire(candidateEntryPath);
process.stdout.write(JSON.stringify({
  ajvPackageManifestPath: requireFromCandidate.resolve(process.argv[2] + "/package.json"),
  candidateEntryUrl,
  jscpdPackageManifestPath: requireFromCandidate.resolve(process.argv[3] + "/package.json"),
  markdownlintPackageManifestPath: requireFromCandidate.resolve(process.argv[4] + "/package.json")
}));`,
    PACKAGE_NAME,
    AJV_PACKAGE_NAME,
    JSCPD_PACKAGE_NAME,
    MARKDOWNLINT_PACKAGE_NAME
  ];
}

function parseCandidateInstallationProbe(
  output: string,
  consumerDirectory: string
): CandidateInstallationProbe {
  let value: unknown;
  try {
    value = JSON.parse(output);
  } catch (error: unknown) {
    throw new Error(
      `candidate installation resolution returned invalid JSON from ${consumerDirectory}: ${errorMessage(error)}`,
      { cause: error }
    );
  }
  if (!validCandidateInstallationProbe(value)) {
    throw new Error(
      `candidate installation resolution returned an invalid result from ${consumerDirectory}`
    );
  }
  return Object.freeze({
    ajvPackageManifestPath: value.ajvPackageManifestPath,
    candidateEntryUrl: value.candidateEntryUrl,
    jscpdPackageManifestPath: value.jscpdPackageManifestPath,
    markdownlintPackageManifestPath: value.markdownlintPackageManifestPath
  });
}

function validCandidateInstallationProbe(value: unknown): value is Readonly<{
  readonly ajvPackageManifestPath: string;
  readonly candidateEntryUrl: string;
  readonly jscpdPackageManifestPath: string;
  readonly markdownlintPackageManifestPath: string;
}> {
  return (
    isNonArrayRecord(value) &&
    typeof value.candidateEntryUrl === "string" &&
    typeof value.ajvPackageManifestPath === "string" &&
    typeof value.jscpdPackageManifestPath === "string" &&
    typeof value.markdownlintPackageManifestPath === "string" &&
    Object.keys(value).length === 4
  );
}

function resolveInstalledCandidateEntry(packageDirectory: string, resolvedUrl: string): string {
  let resolvedEntryPath: string;
  try {
    resolvedEntryPath = fileURLToPath(resolvedUrl);
  } catch (error: unknown) {
    throw new Error(
      `candidate entry resolution returned an invalid file URL for ${packageDirectory}: ${errorMessage(error)}`,
      { cause: error }
    );
  }
  if (!existsSync(resolvedEntryPath))
    throw new Error(`candidate entry resolved to a missing path: ${resolvedEntryPath}`);
  if (!isPathWithin(packageDirectory, resolvedEntryPath))
    throw new Error(`candidate entry resolved outside its installed package: ${resolvedEntryPath}`);
  return resolvedEntryPath;
}

function assertPrivateCandidateConsumer(consumerDirectory: string): void {
  const manifestPath = join(consumerDirectory, "package.json");
  if (!existsSync(manifestPath)) {
    throw new Error(`private candidate consumer package manifest is missing: ${manifestPath}`);
  }
  const manifest = readJsonFile(manifestPath, "private candidate consumer package manifest");
  if (!isNonArrayRecord(manifest) || manifest.private !== true) {
    throw new Error(`candidate consumer must set private: true in ${manifestPath}`);
  }
}

function readJsonFile(filePath: string, description: string): unknown {
  let source: string;
  try {
    source = readFileSync(filePath, "utf8");
  } catch (error: unknown) {
    throw new Error(`could not read ${description} ${filePath}: ${errorMessage(error)}`, {
      cause: error
    });
  }
  try {
    return JSON.parse(source);
  } catch (error: unknown) {
    throw new Error(`could not parse ${description} ${filePath}: ${errorMessage(error)}`, {
      cause: error
    });
  }
}
