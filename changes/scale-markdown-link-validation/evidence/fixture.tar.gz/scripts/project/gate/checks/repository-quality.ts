import { dirname, isAbsolute, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import {
  duplicateDetection,
  fileMetrics,
  functionMetrics,
  markdownLint,
  markdownLinkValidation,
  type DuplicateDetectionOptions,
  type FileMetricsOptions,
  type FunctionMetricsOptions,
  type MarkdownLintOptions,
  type MarkdownLinkValidationOptions
} from "@zxyycom/vibe-check";

const MISE_SCC_COMMAND_ENV = "VIBE_CHECK_SCC_CMD";
const repositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../../../..");
const unavailableScannerDirectory = resolve(
  repositoryRoot,
  ".cache",
  "vibe-check",
  "unavailable-repository-quality-scanner"
);
const repositoryExcludedPatterns = [
  "**/.git",
  "**/.git/**",
  "**/archive/**",
  "**/target/**",
  "**/node_modules/**",
  "**/.venv/**",
  "**/.uv-cache/**",
  "**/.ruff_cache/**",
  "**/dist/**",
  "**/build/**",
  "**/vendor/**",
  "**/generated/**",
  "**/fixtures/**",
  "**/.cache/**",
  "**/cache/**",
  "**/artifacts/**",
  "**/.tmp/**",
  "**/.log/**"
].map((pattern) => `!${pattern}`);
const repositoryFileCodeLines = {
  lowDecisionTokenAllowance: { maximumCodeLines: 500, maximumDecisionTokens: 10 },
  maximum: 300
} as const;
const repositoryFunctionLimits = {
  codeLines: {
    lowComplexityAllowance: { cyclomaticComplexityBelow: 5, maximum: 150 },
    maximum: 50
  },
  cyclomaticComplexity: { maximum: 10 },
  nestingDepth: { maximum: 7 },
  parameters: { maximum: 5 }
} as const;
const lizardPortQualityExclusion = "src/package-checks/function-metrics/analyzer/**";
const productFunctionMetricTestExclusions = [
  "src/**/*.test.ts",
  "src/**/*.test-support.ts"
] as const;
const repositoryMarkdownLintRules = [
  "heading-increment",
  "no-reversed-links",
  "no-missing-space-atx",
  "fenced-code-language",
  "no-empty-links",
  "no-alt-text",
  "reference-links-images",
  "table-column-count"
] as const satisfies NonNullable<MarkdownLintOptions["rules"]>;

export interface RepositoryQualityCheckOptions {
  readonly duplicateDetection: DuplicateDetectionOptions;
  readonly fileMetrics: Omit<FileMetricsOptions, "scanner">;
  readonly functionMetrics: FunctionMetricsOptions;
  readonly markdownLint: MarkdownLintOptions;
  readonly markdownLinkValidation: MarkdownLinkValidationOptions;
}

export interface RepositoryQualityChecks {
  readonly duplicateDetection: ReturnType<typeof duplicateDetection>;
  readonly fileMetrics: ReturnType<typeof fileMetrics>;
  readonly functionMetrics: ReturnType<typeof functionMetrics>;
  readonly markdownLint: ReturnType<typeof markdownLint>;
  readonly markdownLinkValidation: ReturnType<typeof markdownLinkValidation>;
}

export interface RepositoryQualityScannerCommands {
  readonly scc: string;
}

/** Complete repository-private policy owned by the repository-quality Check group. */
export const PROJECT_GATE_REPOSITORY_QUALITY_OPTIONS = {
  duplicateDetection: {
    codeAreas: {
      "product-source": {
        files: {
          useDefaultExcludes: true,
          patterns: ["src/**/*.ts", ...repositoryExcludedPatterns, `!${lizardPortQualityExclusion}`]
        },
        minimumLines: 3,
        minimumTokens: 75
      },
      "schemas-examples": {
        files: {
          useDefaultExcludes: true,
          patterns: [
            "docs/schemas/**",
            "docs/examples/**",
            ...repositoryExcludedPatterns,
            "!docs/schemas/historical/**"
          ]
        },
        minimumLines: 3,
        minimumTokens: 150
      },
      "script-tests": {
        files: {
          useDefaultExcludes: true,
          patterns: ["scripts/**/*.test.ts", ...repositoryExcludedPatterns]
        },
        minimumLines: 3,
        minimumTokens: 100
      },
      "script-tooling": {
        files: {
          useDefaultExcludes: true,
          patterns: ["scripts/**/*.ts", ...repositoryExcludedPatterns, "!scripts/**/*.test.ts"]
        },
        minimumLines: 3,
        minimumTokens: 75
      }
    },
    findingPolicy: "blocking"
  },
  fileMetrics: {
    codeAreas: {
      "docs-specs": {
        codeLines: repositoryFileCodeLines,
        files: {
          useDefaultExcludes: true,
          patterns: [
            "docs/**/*.md",
            "changes/**/*.md",
            ...repositoryExcludedPatterns,
            "!docs/examples/**",
            "!docs/investigations/_resources/**",
            "!docs/schemas/**"
          ]
        }
      },
      "product-source": {
        codeLines: repositoryFileCodeLines,
        files: {
          useDefaultExcludes: true,
          patterns: ["src/**/*.ts", ...repositoryExcludedPatterns, `!${lizardPortQualityExclusion}`]
        }
      },
      "schemas-examples": {
        codeLines: repositoryFileCodeLines,
        files: {
          useDefaultExcludes: true,
          patterns: [
            "docs/schemas/**",
            "docs/examples/**",
            ...repositoryExcludedPatterns,
            "!docs/schemas/historical/**"
          ]
        }
      },
      "script-tooling": {
        codeLines: repositoryFileCodeLines,
        files: {
          useDefaultExcludes: true,
          patterns: ["scripts/**/*.ts", ...repositoryExcludedPatterns, "!scripts/**/*.test.ts"]
        }
      }
    },
    findingPolicy: "blocking",
    findingWaivers: [
      {
        identity: {
          metric: "code-lines",
          path: "docs/guides/building-project-gate.md"
        },
        reason:
          "用户确认保留单页九场景与十个独立可执行片段；行数来自同页教学路径，不以压缩代码或删除安全说明满足门限。仅豁免此文件的行数，保留测量与 Finding。"
      }
    ]
  },
  functionMetrics: {
    codeAreas: {
      "product-source": {
        files: {
          useDefaultExcludes: true,
          patterns: [
            "src/**/*.ts",
            ...repositoryExcludedPatterns,
            `!${lizardPortQualityExclusion}`,
            ...productFunctionMetricTestExclusions.map((pattern) => `!${pattern}`)
          ]
        },
        limits: repositoryFunctionLimits
      },
      "script-tooling": {
        files: {
          useDefaultExcludes: true,
          patterns: ["scripts/**/*.ts", ...repositoryExcludedPatterns, "!scripts/**/*.test.ts"]
        },
        limits: repositoryFunctionLimits
      }
    },
    findingPolicy: "blocking",
    findingWaivers: [
      {
        identity: {
          functionName: "createProjectGateEntries",
          metric: "function-code-density",
          path: "scripts/project/gate/definition.ts",
          startLine: 208
        },
        reason:
          "Gate 的完整顺序 manifest 是低分支的声明清单；按行数拆分会隐藏 Check 顺序和选择，其他函数指标仍阻断。"
      }
    ]
  },
  markdownLint: {
    checkId: "markdown-lint",
    files: { patterns: ["docs/**/*.md", "changes/**/*.md"] },
    findingPolicy: "non-blocking",
    rules: repositoryMarkdownLintRules,
    cache: {
      enabled: true,
      directory: resolve(repositoryRoot, ".cache", "vibe-check", "markdown-lint-findings")
    }
  },
  markdownLinkValidation: {
    cache: {
      enabled: true,
      directory: resolve(repositoryRoot, ".cache", "vibe-check", "markdown-link-parse-facts")
    },
    files: {
      useDefaultExcludes: true,
      patterns: ["docs/**/*.md", "changes/**/*.md", ...repositoryExcludedPatterns]
    },
    findingPolicy: "blocking",
    limits: { maxTargetReads: 3_000 }
  }
} as const satisfies RepositoryQualityCheckOptions;

/** Resolves Gate-owned scanner commands without admitting ambient PATH fallbacks. */
export function repositoryQualityScannerCommands(
  environment: NodeJS.ProcessEnv = process.env
): RepositoryQualityScannerCommands {
  return Object.freeze({
    scc: absoluteScannerCommand(environment[MISE_SCC_COMMAND_ENV], MISE_SCC_COMMAND_ENV)
  });
}

/** Binds the root Definition's repository policy to its package Check constructors. */
export function createRepositoryQualityChecks(
  options: RepositoryQualityCheckOptions,
  scanners: RepositoryQualityScannerCommands = repositoryQualityScannerCommands()
): RepositoryQualityChecks {
  return Object.freeze({
    duplicateDetection: duplicateDetection(options.duplicateDetection),
    fileMetrics: fileMetrics({
      ...options.fileMetrics,
      scanner: { executable: absoluteScannerCommand(scanners.scc, MISE_SCC_COMMAND_ENV) }
    }),
    functionMetrics: functionMetrics(options.functionMetrics),
    markdownLint: markdownLint(options.markdownLint),
    markdownLinkValidation: markdownLinkValidation(options.markdownLinkValidation)
  });
}

function absoluteScannerCommand(value: string | undefined, name: string): string {
  if (value !== undefined && isAbsolute(value)) return value;
  return resolve(unavailableScannerDirectory, name);
}
