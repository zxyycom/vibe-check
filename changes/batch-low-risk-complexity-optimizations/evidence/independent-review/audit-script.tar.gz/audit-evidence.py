import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess

ROOT = Path('/workspace/vibe-check')
TMP = Path('/tmp/vibe-low-risk-review.5n66j6')
EVIDENCE = ROOT / 'changes/batch-low-risk-complexity-optimizations/evidence'
BASELINE = 'b3c8fecce5a2ff835948f76f9fd4fa5a8e2fe853'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def manifest(path):
    return [line.split('  ', 1) for line in path.read_text().splitlines()]

for mode, manifest_name in [('before', 'before-src-sha256-relative.txt'), ('after', 'after-final-src-sha256-relative.txt')]:
    entries = manifest(EVIDENCE / 'identity' / manifest_name)
    for expected, relative in entries:
        data = subprocess.check_output(['git', 'show', f'{BASELINE}:{relative}'], cwd=ROOT) if mode == 'before' else (ROOT / relative).read_bytes()
        assert digest(data) == expected, (mode, relative)
    print(mode, 'source SHA verified:', len(entries))

for expected, relative in manifest(EVIDENCE / 'artifact-sha256.txt'):
    assert digest((EVIDENCE / relative).read_bytes()) == expected, relative
print('Archived delivery SHA verified')
for expected, relative in manifest(EVIDENCE / 'raw-text-original-sha256.txt'):
    assert digest((TMP / relative).read_bytes()) == expected, relative
print('Raw-text original bytes SHA verified')
for expected, relative in manifest(EVIDENCE / 'root-validation/artifact-sha256.txt'):
    assert digest((EVIDENCE / 'root-validation' / relative).read_bytes()) == expected, relative
print('Root-validation archive SHA verified')
before_helper = (TMP / 'harness/before-workloads.ts').read_text().replace('../before/', '../SOURCE/')
after_helper = (TMP / 'harness/after-workloads.ts').read_text().replace('../after-final/', '../SOURCE/')
assert before_helper == after_helper
print('Before/after workload helper identical apart from source root')

summary = json.loads((EVIDENCE / 'summary.json').read_text())
assert len(summary['rows']) == 37
assert (TMP / 'comparison-results/summary.json').read_bytes() == (EVIDENCE / 'summary.json').read_bytes()
runs = {}
for pair in range(5):
    for mode in ['before', 'after']:
        path = TMP / f'comparison-results/formal-0{pair}-{mode}.json'
        run = json.loads(path.read_text())
        assert run['mode'] == mode and len(run['rows']) == 37
        assert (path.with_suffix('.stderr.txt')).stat().st_size == 0
        runs[pair, mode] = run
assert len({run['processId'] for run in runs.values()}) == 10
expected_order = ''.join(f'{pair}\t{mode}\n' for pair in range(5) for mode in (['before', 'after'] if pair % 2 == 0 else ['after', 'before']))
assert (TMP / 'comparison-results/execution-order.txt').read_text() == expected_order
smokes = [json.loads((TMP / f'comparison-results/smoke-{mode}.json').read_text()) for mode in ['before', 'after']]
for index, aggregate in enumerate(summary['rows']):
    rows = [run['rows'][index] for run in runs.values()]
    for row in rows:
        for key in ['name', 'size', 'iterations', 'boundary', 'output']:
            assert row[key] == rows[0][key], (index, key)
        assert len(row['samplesMsPerCall']) == 7
        assert row['warmupCalls'] == 3 * row['iterations']
    for smoke in smokes:
        assert smoke['rows'][index]['output'] == rows[0]['output']
    process_medians = {}
    for mode in ['before', 'after']:
        samples = [sample for pair in range(5) for sample in runs[pair, mode]['rows'][index]['samplesMsPerCall']]
        med = statistics.median(samples)
        distribution = aggregate[f'{mode}MsPerCall']
        for key, value in [('median', med), ('mad', statistics.median(abs(s-med) for s in samples)), ('min', min(samples)), ('max', max(samples)), ('count', 35)]:
            assert math.isclose(distribution[key], value, rel_tol=1e-14), (index, key)
        process_medians[mode] = [statistics.median(runs[pair, mode]['rows'][index]['samplesMsPerCall']) for pair in range(5)]
        assert aggregate[f'{mode}ProcessMedians'] == process_medians[mode]
    ratios = [a/b for a, b in zip(process_medians['after'], process_medians['before'])]
    assert aggregate['pairedAfterOverBefore'] == ratios
    assert aggregate['afterOverBefore'] == aggregate['afterMsPerCall']['median'] / aggregate['beforeMsPerCall']['median']
    print(aggregate['name'], aggregate['size'], 'paired median', round(statistics.median(ratios), 4))
print('All 37 workload full-output parity, metadata, 2590 batch samples and paired statistics independently verified')
