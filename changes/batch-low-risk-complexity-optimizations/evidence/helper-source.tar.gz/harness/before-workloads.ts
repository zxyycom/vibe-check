import { mkdir } from "node:fs/promises";
import { join } from "node:path";
import { parseUniqueIdentifiers } from "../before/src/project-definition/check-tree/collection-authoring.ts";
import { normalizeCheckOutcome } from "../before/src/check-settlement/outcome-normalization.ts";
import { hasExactPlainRecordKeys } from "../before/src/data-boundary/closed-values.ts";
import {
  defineConfig,
  normalizeProjectDefinition,
  type AdmissionPolicyContext,
  type SchedulerRawMeasurement
} from "../before/src/project-definition/project-definition.ts";
import { selectEffectiveCheckIds } from "../before/src/project-run/check-execution/flag-controls.ts";
import { createCheckDependencies } from "../before/src/project-run/check-execution/dependencies.ts";
import { createCoreCheckSession } from "../before/src/check-settlement/session.ts";
import {
  resolveInvocationPaths,
  artifactDirectoryForCheck
} from "../before/src/project-run/invocation/paths.ts";
import { prepareTaskGraph } from "../before/src/project-run/task-scheduler/graph.ts";
import { applyDuplicateAreaPolicy } from "../before/src/package-checks/duplicate-detection/area-policy.ts";
import { planSccBatches } from "../before/src/package-checks/file-metrics/scc/batch-planner.ts";
import { orderedMarkdownLintCandidates } from "../before/src/package-checks/markdown-lint/records.ts";
import { MARKDOWN_LINT_RULE_NAMES } from "../before/src/package-checks/markdown-lint/options.ts";
import type { MarkdownLintBackendFinding } from "../before/src/package-checks/markdown-lint/adapter.ts";
import { createSchedulerCriticalPathSnapshot } from "../before/src/package-tools/learned-critical-path/critical-path-ranking.ts";
import { createLearnedCriticalPathStrategy } from "../before/src/package-tools/learned-critical-path/strategy.ts";
import { createAdmissionGraph } from "../before/src/project-run/task-scheduler/admission-core/core.ts";
import {
  createSchedulerPredictionSnapshot,
  createSchedulerHistoryIdentity
} from "../before/src/package-tools/learned-critical-path/duration-model/prediction.ts";
import { recordSchedulerHistory } from "../before/src/package-tools/learned-critical-path/duration-model/recording.ts";
import { freezeSchedulerHistoryModel } from "../before/src/package-tools/learned-critical-path/duration-model/bounded-history.ts";
import type { BenchmarkWorkload } from "./benchmark-contract.ts";

function idsFor(size: number): readonly string[] {
  return Array.from({ length: size }, (_, index) => `id-${String(index).padStart(5, "0")}`);
}
function requireText(text: string | undefined): string {
  if (text === undefined) throw new Error("missing fixture identifier");
  return text;
}
function emptyMeasurement(): AdmissionPolicyContext["measurement"] {
  return Object.freeze({
    cumulative: Object.freeze({
      declarativeFingerprint: "benchmark",
      discrete: Object.freeze({ acceptedWaitCount: 0, admittedCount: 0, maxRunning: 0 }),
      peaks: Object.freeze({
        admissionViablePendingTaskCount: 0,
        admissiblePendingTaskCount: 0,
        capacityBlockedTaskCount: 0,
        mutexBlockedTaskCount: 0
      }),
      timing: Object.freeze({
        availability: "unavailable" as const,
        reason: "clock-threw" as const
      })
    }),
    measurementAt: () => undefined,
    measurementCount: 0
  });
}
function availableMeasurement(ids: readonly string[]): SchedulerRawMeasurement {
  const endedAtMonotonicMs = ids.length * 20;
  const taskSlotMs = ids.reduce((total, _, index) => total + (index % 13) + 1, 0);
  return Object.freeze({
    declarativeFingerprint: "sha256:benchmark",
    discrete: Object.freeze({
      acceptedWaitCount: 0,
      admittedCount: ids.length,
      completionTailActiveTaskIds: Object.freeze([]),
      lastSettledTaskId: ids.at(-1) ?? null,
      maxRunning: 1
    }),
    peaks: Object.freeze({
      admissiblePendingTaskCount: ids.length,
      admissionViablePendingTaskCount: ids.length,
      capacityBlockedTaskCount: 0,
      mutexBlockedTaskCount: 0
    }),
    timing: Object.freeze({ availability: "available" as const }),
    timingFacts: Object.freeze({
      acceptedWaitMs: 0,
      admissions: Object.freeze(
        ids.map((taskId, index) =>
          Object.freeze({
            admissionDelay: Object.freeze({
              admissiblePendingMs: index * 20,
              capacityBlockedMs: 0,
              mutexBlockedMs: 0
            }),
            admittedAtMonotonicMs: index * 20,
            settledAtMonotonicMs: index * 20 + (index % 13) + 1,
            taskId
          })
        )
      ),
      effectiveCapacitySlotMs: 4 * endedAtMonotonicMs,
      endedAtMonotonicMs,
      rootCapacitySlotMs: 4 * endedAtMonotonicMs,
      schedulerControlPathMs: endedAtMonotonicMs,
      schedulerDecisionObservationMs: 0,
      startedAtMonotonicMs: 0,
      taskSlotMs
    })
  });
}
export async function createWorkloads(stateRoot: string): Promise<readonly BenchmarkWorkload[]> {
  const workloads: BenchmarkWorkload[] = [];
  function add(
    name: string,
    size: number,
    iterations: number,
    boundary: string,
    invoke: () => unknown,
    asynchronous = false
  ): void {
    workloads.push({ name, size, iterations, boundary, invoke, asynchronous });
  }
  for (const size of [8, 512]) {
    const ids = idsFor(size);
    const iterations = size === 8 ? 300 : 8;
    const mixedIds = ids.flatMap((id, index) => (index % 3 === 0 ? [id, id] : [id]));
    add(
      "C01-identifier-dedup",
      size,
      iterations,
      "parseUniqueIdentifiers closed-array snapshot + insertion-order dedup",
      () => parseUniqueIdentifiers(mixedIds)
    );
    const knownCheckIds = new Set(ids);
    const validReason = {
      status: "unavailable",
      reason: { code: "prerequisite-not-passed", checkIds: ids }
    };
    const duplicateReason = {
      status: "unavailable",
      reason: { code: "prerequisite-not-passed", checkIds: [...ids, requireText(ids[0])] }
    };
    add(
      "C03-reason-unique-and-reject",
      size,
      iterations,
      "normalizeCheckOutcome valid list + late duplicate rejection",
      () => [
        normalizeCheckOutcome({ knownCheckIds, productOutcome: true, value: validReason }),
        normalizeCheckOutcome({ knownCheckIds, productOutcome: true, value: duplicateReason })
      ]
    );
    const normalized = normalizeProjectDefinition(
      defineConfig({
        checks: ids.map((checkId, index) => ({
          checkId,
          displayName: checkId,
          enabledByFlags: {
            when: { kind: "all" as const, conditions: [checkId, requireText(ids[0])] }
          },
          execute: () => ({ status: "passed" as const, data: { index } })
        }))
      })
    );
    add(
      "R08-flag-membership",
      size,
      iterations,
      "selectEffectiveCheckIds full selection including run flags membership construction",
      () => selectEffectiveCheckIds(normalized.checks, ids)
    );
    const session = createCoreCheckSession(
      ids.map((checkId) => ({ definition: { checkId, displayName: checkId } }))
    );
    for (const [index, checkId] of ids.entries())
      session.openCheckScope(checkId).settle({ status: "passed", data: { index } });
    const dependencyInput = {
      checkId: "consumer",
      directDependsOnCheckIds: ids,
      directRelationCheckIds: ids,
      diagnosticLogger: undefined,
      handoffsByCheckId: new Map(),
      session
    };
    const dependencies = createCheckDependencies(dependencyInput);
    add(
      "R08-dependency-reads",
      size,
      iterations,
      "prepared createCheckDependencies closure; n authorized string gets + one unauthorized get",
      () => [...ids.map((id) => dependencies.get(id)), dependencies.get("undeclared")]
    );
    add(
      "R08-dependency-build-and-reads",
      size,
      iterations,
      "createCheckDependencies plus n authorized string gets; includes index construction",
      () => {
        const fresh = createCheckDependencies(dependencyInput);
        return ids.map((id) => fresh.get(id));
      }
    );
    const pathInput = {
      checkArtifactBaseDirectory: "artifacts",
      checkIds: ids,
      diagnosticLogFileNaming: "channel" as const,
      diagnosticLogSuffix: undefined,
      outputConfiguration: {
        ...normalized.declarative.outputs,
        progressRendering: { ...normalized.declarative.outputs.progressRendering, formatter: null }
      },
      progressLogFile: undefined,
      projectRoot: "/tmp/vibe-low-risk-fixture"
    };
    const paths = resolveInvocationPaths(pathInput);
    add(
      "R08-artifact-lookups",
      size,
      iterations,
      "resolved invocation path object; n check-local directory reads + missing lookup; no filesystem writes",
      () => [
        ...ids.map((id) => artifactDirectoryForCheck(paths, id)),
        artifactDirectoryForCheck(paths, "undeclared")
      ]
    );
    add(
      "R08-artifact-build-and-lookups",
      size,
      iterations,
      "resolveInvocationPaths plus n check-local directory reads; includes hashes and index build",
      () => {
        const fresh = resolveInvocationPaths(pathInput);
        return ids.map((id) => artifactDirectoryForCheck(fresh, id));
      }
    );
    const graphInput = {
      tasks: ids.map((id) => ({ id, scopeId: id })),
      scopes: ids.map((id) => ({ id, maxParallel: 1, activationTaskIds: [id], terminalTaskId: id }))
    };
    add(
      "R04-four-singleton-prepare",
      size,
      iterations,
      "four separate prepareTaskGraph calls; singleton scopes; no cross-stage reuse; excludes public Run shell",
      () => Array.from({ length: 4 }, () => prepareTaskGraph(graphInput, 4))
    );
    const noScopeInput = { tasks: ids.map((id) => ({ id })) };
    add(
      "R04-four-no-scope-prepare",
      size,
      iterations,
      "four separate prepareTaskGraph calls; common unscoped graph protects no-scope path; no cross-stage reuse; excludes public Run shell",
      () => Array.from({ length: 4 }, () => prepareTaskGraph(noScopeInput, 4))
    );
    const graph = prepareTaskGraph(graphInput, 4).schedulerGraphSnapshot;
    const prediction = {
      predictions: ids.map((taskId, index) => ({ estimatedDurationMs: (index % 7) + 1, taskId }))
    };
    add(
      "T01-critical-path-preparation",
      size,
      iterations,
      "createSchedulerCriticalPathSnapshot incl prediction lookup + frozen score DTO; independent task graph",
      () => createSchedulerCriticalPathSnapshot(graph, prediction)
    );
    const modelInputs = ids.map((taskId) =>
      Object.freeze({
        authoredOptions: Object.freeze({ taskId, revision: "benchmark-v1" }),
        checkId: taskId,
        flags: null,
        taskId
      })
    );
    const boundedHistory = freezeSchedulerHistoryModel({
      latestObservationSequence: size * 4,
      series: modelInputs.map((input, index) => ({
        identityDigest: createSchedulerHistoryIdentity(input),
        latestObservationSequence: index * 4 + 4,
        samples: Array.from({ length: 4 }, (_, sampleIndex) => ({
          durationMs: (index % 13) + sampleIndex + 1,
          observationSequence: index * 4 + sampleIndex + 1,
          settlementKind: "completed" as const
        }))
      }))
    });
    add(
      "T01-history-prediction",
      size,
      size === 8 ? 30 : 2,
      "createSchedulerPredictionSnapshot with immutable in-memory bounded history: n matching series x4 samples; includes history index construction, identity hashing, learned/prior, digest and frozen DTO; excludes IO",
      () => createSchedulerPredictionSnapshot(boundedHistory, modelInputs)
    );
    const modelPrediction = createSchedulerPredictionSnapshot(boundedHistory, modelInputs);
    const recordingInput = {
      history: boundedHistory,
      prediction: modelPrediction,
      rawMeasurement: availableMeasurement(ids),
      settledTasks: ids.map((taskId, index) => ({
        kind: index % 7 === 0 ? ("failed" as const) : ("completed" as const),
        taskId
      })),
      maxSamplesPerSeries: 4,
      maxSeries: size
    };
    add(
      "T01-history-recording",
      size,
      size === 8 ? 100 : 3,
      "recordSchedulerHistory with immutable prepared predictions, n existing series x4 samples and n ordered available admissions; includes prediction index construction, merge, bounded 4-sample retention and freeze; synthetic complete terminal input, no storage/terminalEffect",
      () => recordSchedulerHistory(recordingInput)
    );
    const history = join(stateRoot, `learned-${size}`);
    await mkdir(history, { recursive: true });
    const strategy = createLearnedCriticalPathStrategy({
      stateDirectory: history,
      identityForTask: (task) => ({ taskId: task.taskId })
    });
    if (strategy.kind !== "prepared") throw new Error("expected prepared learned strategy");
    const context: AdmissionPolicyContext = Object.freeze({
      activeScopeIds: Object.freeze([]),
      admissionState: createAdmissionGraph({ graph, maxParallel: 4 }).initialState(),
      candidates: Object.freeze(
        [...ids].reverse().map((taskId) => Object.freeze({ canAdmit: true, taskId }))
      ),
      capacity: Object.freeze({ effectiveMaxParallel: 4, maxParallel: 4, running: 0 }),
      graph,
      measurement: emptyMeasurement(),
      runningTaskIds: Object.freeze([]),
      runtime: Object.freeze({ abortRequested: false, cancelled: false }),
      settledTaskIds: Object.freeze([])
    });
    const prepared = await strategy.prepare({ graph });
    const continuation = Object.freeze({
      ...context,
      activeScopeIds: Object.freeze(ids.filter((_, index) => index % 2 === 0))
    });
    const wait = Object.freeze({
      ...context,
      candidates: Object.freeze(
        context.candidates.map((candidate) => Object.freeze({ ...candidate, canAdmit: false }))
      )
    });
    add(
      "T01-T02-prepared-decisions",
      size,
      iterations,
      "public strategy.prepare outside timer; synchronous decide on tightening, active continuation, and wait boundaries",
      () => [prepared.decide(context), prepared.decide(continuation), prepared.decide(wait)]
    );
    add(
      "T01-T02-public-prepare",
      size,
      size === 8 ? 10 : 2,
      "public learned strategy.prepare with empty existing directory; includes async history read, identity, predictions, scores and immutable index construction; no terminalEffect/write",
      async () => {
        const fresh = await strategy.prepare({ graph });
        return [fresh.decide(context), fresh.decide(continuation), fresh.decide(wait)];
      },
      true
    );
  }
  for (const size of [2, 5, 512]) {
    const keys = idsFor(size);
    const record = Object.fromEntries(keys.map((key, index) => [key, index]));
    add(
      "C05-exact-keys-conditional",
      size,
      size <= 5 ? 10000 : 100,
      "hasExactPlainRecordKeys existing plain record; protects common 2/5-key schemas; no snapshot cost",
      () => [
        hasExactPlainRecordKeys(record, keys),
        hasExactPlainRecordKeys({ ...record, extra: true }, keys)
      ]
    );
  }
  for (const areaCount of [4, 256]) {
    const areas = idsFor(areaCount).map((codeArea, index) => ({
      approvedExactPaths: index % 3 === 0 ? ["a.ts"] : ["a.ts", "b.ts"],
      codeArea,
      minimumLines: 3 + (index % 3),
      minimumTokens: 5 + (index % 5)
    }));
    const fragments = Array.from({ length: areaCount === 4 ? 4 : 64 }, (_, id) => ({
      codeAreas: [],
      id,
      lineCount: 10,
      tokenCount: 20,
      locations: [
        { path: "a.ts", startLine: 1, endLine: 10 },
        { path: "b.ts", startLine: 2, endLine: 11 }
      ]
    }));
    add(
      "K04-area-intersection",
      areaCount,
      areaCount === 4 ? 300 : 3,
      "applyDuplicateAreaPolicy incl path-policy build, 2-location overlap intersection, strict thresholds and ordered annotations",
      () => applyDuplicateAreaPolicy(fragments, areas)
    );
  }
  for (const size of [8, 2048]) {
    const paths = idsFor(size).map((id) => `src/${id}.ts`);
    add(
      "K07-scc-batch-planning",
      size,
      size === 8 ? 1000 : 8,
      "planSccBatches fixed 28000 UTF16 ceiling; stable multi-batch transport planning only; no scanner process",
      () => planSccBatches("scc", ["--no-config", "--by-file", "--format", "csv"], paths)
    );
  }
  for (const size of [8, 2048]) {
    const findings: readonly {
      readonly path: string;
      readonly finding: MarkdownLintBackendFinding;
    }[] = Array.from({ length: size }, (_, index) => ({
      path: `doc-${index % 3}.md`,
      finding: {
        lineNumber: ((index * 617) % 127) + 1,
        range: index % 4 === 0 ? null : [(index % 5) + 1, index % 7],
        rule:
          MARKDOWN_LINT_RULE_NAMES[index % MARKDOWN_LINT_RULE_NAMES.length] ?? "heading-increment"
      }
    }));
    add(
      "K14-ordered-findings",
      size,
      size === 8 ? 300 : 5,
      "orderedMarkdownLintCandidates incl raw coordinate sort and public frozen range/IDs; null ranges and duplicate positions",
      () => orderedMarkdownLintCandidates(findings, MARKDOWN_LINT_RULE_NAMES)
    );
  }
  return Object.freeze(workloads);
}
