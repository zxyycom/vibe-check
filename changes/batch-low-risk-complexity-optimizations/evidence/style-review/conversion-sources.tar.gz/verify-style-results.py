"""Verify the scoped style replay without altering or excluding raw samples.

Temporary verification companion; retain with this Change's style replay evidence.
"""

import json
import math
from pathlib import Path
import statistics


ROOT = Path("/tmp/vibe-low-risk-style.9xQguq")
RESULTS = ROOT / "candidate/style-flags-results"


def read_runs() -> dict:
    runs = {}
    for pair in range(5):
        for mode in ["before", "after"]:
            path = RESULTS / f"formal-0{pair}-{mode}.json"
            run = json.loads(path.read_text())
            assert run["mode"] == mode and len(run["rows"]) == 2
            assert path.with_suffix(".stderr.txt").stat().st_size == 0
            runs[pair, mode] = run
    assert len({run["processId"] for run in runs.values()}) == 10
    expected_order = "".join(
        f"{pair}\t{mode}\n"
        for pair in range(5)
        for mode in (["before", "after"] if pair % 2 == 0 else ["after", "before"])
    )
    assert (RESULTS / "execution-order.txt").read_text() == expected_order
    return runs


def verify_rows(runs: dict, summary: dict) -> None:
    smoke = json.loads((ROOT / "equivalence-results/smoke-current.json").read_text())
    reference_rows = [row for row in smoke["rows"] if row["name"] == "R08-flag-membership"]
    assert len(reference_rows) == len(summary["rows"]) == 2
    for index, (size, iterations) in enumerate([(8, 300), (512, 8)]):
        reference = reference_rows[index]
        aggregate = summary["rows"][index]
        for run in runs.values():
            row = run["rows"][index]
            assert row["size"] == size and row["iterations"] == iterations
            assert row["warmupCalls"] == 3 * iterations
            assert len(row["samplesMsPerCall"]) == 7
            assert all(math.isfinite(sample) and sample >= 0 for sample in row["samplesMsPerCall"])
            for key in ["name", "size", "boundary", "output"]:
                assert row[key] == reference[key], (index, key)
            for key in ["name", "size", "boundary", "iterations"]:
                assert row[key] == aggregate[key], (index, key)
        process_medians = {}
        for mode in ["before", "after"]:
            samples = [
                sample
                for pair in range(5)
                for sample in runs[pair, mode]["rows"][index]["samplesMsPerCall"]
            ]
            median = statistics.median(samples)
            distribution = aggregate[f"{mode}MsPerCall"]
            expected = {
                "median": median,
                "mad": statistics.median(abs(sample - median) for sample in samples),
                "min": min(samples),
                "max": max(samples),
                "count": 35,
            }
            for key, value in expected.items():
                assert math.isclose(distribution[key], value, rel_tol=1e-14), (index, mode, key)
            process_medians[mode] = [
                statistics.median(runs[pair, mode]["rows"][index]["samplesMsPerCall"])
                for pair in range(5)
            ]
            assert aggregate[f"{mode}ProcessMedians"] == process_medians[mode]
        ratios = [
            after / before
            for after, before in zip(process_medians["after"], process_medians["before"], strict=True)
        ]
        assert aggregate["pairedAfterOverBefore"] == ratios
        expected_ratio = aggregate["afterMsPerCall"]["median"] / aggregate["beforeMsPerCall"]["median"]
        assert aggregate["afterOverBefore"] == expected_ratio
        assert aggregate["fullOutputParity"] is True
        print(f"Verified flags/{size}: 5 pairs, 70 samples, full output and all statistics")


def main() -> None:
    runs = read_runs()
    summary = json.loads((RESULTS / "summary.json").read_text())
    assert summary["files"] == sorted(path.name for path in RESULTS.glob("formal-*-*.json"))
    verify_rows(runs, summary)
    print("Verified 10 independent process IDs and alternating execution order; no exclusions")


if __name__ == "__main__":
    main()
