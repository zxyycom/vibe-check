# file-lifecycle-hygiene：本批编码规范审查候选

对象：`/tmp/vibe-low-risk-style.9xQguq/`。
来源：Change 的 `helper-source.tar.gz`、`audit-script.tar.gz` 解压到 `historical/`；
`candidate/` 从这些历史内容复制并按本轮规范审查修复。旧档案和原 `/tmp` 均未写入。
形成时间：2026-10-12T08:09:56.668342552Z（目录 stat birth time）。
状态确认时间：2026-10-12T08:32:01Z（实际 date -u）。
用途：隔离保存规范改进、原始定义等价与 style-before/style-after flag 成本复核。
状态与保留原因：等待主线程完成新归档和最终证据交接；不代表旧测量使用了新 helper。
后续处理：新版 helper、等价验证和 scoped 复核归档并核对后，本目录可由用户/主线程明确清理。

- `historical/`：原 helper/audit 的只读比较来源；另有 `audit-source-bound.py`，它是为本轮
  原/新审计对照而生成的隔离副本，只把 after source 绑定原快照，不是旧执行源码。
- `candidate/harness/`、`candidate/audit-evidence.py`：当前复放 helper 候选。
- `candidate/{before,after-final,c05-candidate,style-before}`：指向原冻结源码的只读目录符号链接，
  不归档为 source bytes；`candidate/style-after/` 是本轮当前源码的独立 722-file snapshot。
- `candidate-helper-sha256.txt`、`style-{before,after}-src-sha256.txt`：本轮形成的冻结身份。
- `equivalence-results/`：候选对原37行和当前源码的 smoke；其毫秒只为执行完整性，不作性能结果。
- `original-audit-output.txt`、`candidate-audit-output.txt`：同一显式旧 source/raw 绑定下的逐字审计对照。
- 根目录的 refactor/sync/bind/verify TS：本轮短期转换/自验证材料，不是长期框架或原测量源码。
