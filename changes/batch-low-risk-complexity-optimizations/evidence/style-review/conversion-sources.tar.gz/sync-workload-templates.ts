import { readFile, writeFile } from "node:fs/promises";

// One-off author-template synchronization; retain only with this Change's conversion evidence.
const harness = "/tmp/vibe-low-risk-style.9xQguq/candidate/harness";
const workloadSource = await readFile(`${harness}/before-workloads.ts`, "utf8");
const workloadTemplate = workloadSource
  .replaceAll("../before/", "__SOURCE_ROOT__/")
  .replaceAll("size: size,", "size,")
  .replaceAll("iterations: iterations,", "iterations,");
await writeFile(`${harness}/workloads-template.txt`, workloadTemplate);
for (const [mode, sourceRoot] of [
  ["before", "../before"],
  ["after", "../after-final"]
] as const) {
  await writeFile(
    `${harness}/${mode}-workloads.ts`,
    workloadTemplate.replaceAll("__SOURCE_ROOT__", sourceRoot)
  );
}
const c05Source = await readFile(`${harness}/c05-before-workloads.ts`, "utf8");
const c05Template = c05Source.replaceAll("../before/", "__SOURCE_ROOT__/");
await writeFile(`${harness}/c05-template.txt`, c05Template);
for (const [mode, sourceRoot] of [
  ["before", "../before"],
  ["after", "../c05-candidate"]
] as const) {
  await writeFile(
    `${harness}/c05-${mode}-workloads.ts`,
    c05Template.replaceAll("__SOURCE_ROOT__", sourceRoot)
  );
}
