import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import ts from "/workspace/vibe-check/node_modules/typescript/lib/typescript.js";

// One-off AST/source transformation; retain only with this Change's conversion evidence.
const root = "/tmp/vibe-low-risk-style.9xQguq";
const original = await readFile(`${root}/historical/harness/before-workloads.ts`, "utf8");
const source = ts.createSourceFile("before-workloads.ts", original, ts.ScriptTarget.Latest, true);
const changes: { readonly start: number; readonly end: number; readonly text: string }[] = [];
function visit(node: ts.Node): void {
  if (ts.isCallExpression(node) && node.expression.getText(source) === "add") {
    const args = node.arguments.map((argument) => argument.getText(source));
    assert(args.length === 5 || args.length === 6);
    const [name, size, iterations, boundary, invoke] = args;
    changes.push({
      start: node.getStart(source),
      end: node.end,
      text: `workloads.push({ name: ${name}, size: ${size}, iterations: ${iterations}, boundary: ${boundary}, invoke: ${invoke}, asynchronous: ${args[5] ?? "false"} })`
    });
  }
  ts.forEachChild(node, visit);
}
visit(source);
let transformed = original;
for (const change of changes.sort((left, right) => right.start - left.start)) {
  transformed = transformed.slice(0, change.start) + change.text + transformed.slice(change.end);
}
const authorPrefix = transformed.slice(
  0,
  transformed.indexOf("export async function createWorkloads")
);
const sizedStart = transformed.indexOf("    const mixedIds =");
const sizedEnd = transformed.indexOf("\n  }\n  for (const size of [2, 5, 512])", sizedStart);
const sizedBody = transformed.slice(sizedStart, sizedEnd);
const markers = [
  "    const mixedIds =",
  "    const knownCheckIds =",
  "    const normalized =",
  "    const session =",
  "    const pathInput =",
  "    const graphInput =",
  "    const prediction =",
  "    const modelInputs =",
  "    const history ="
];
const parts = markers.map((marker, index) => {
  const start = sizedBody.indexOf(marker);
  const end =
    index === markers.length - 1 ? sizedBody.length : sizedBody.indexOf(markers[index + 1]!);
  assert(start >= 0 && end > start, marker);
  return sizedBody.slice(start, end);
});
const [
  identifiers,
  reasons,
  flags,
  dependencies,
  artifacts,
  graphSetup,
  critical,
  history,
  learned
] = parts;
assert(flags !== undefined && graphSetup !== undefined && learned !== undefined);
const flagSetupEnd = flags.indexOf("    workloads.push(");
const flagSetup = flags.slice(0, flagSetupEnd).replace("    const normalized =", "  return");
const flagWorkload = flags.slice(flagSetupEnd);
const graphSplit = graphSetup.indexOf("    const graph =");
assert(graphSplit > 0);
const graphWorkload = graphSetup.slice(0, graphSplit);
const graphResult = graphSetup.slice(graphSplit);
const normalizedType = "ReturnType<typeof normalizeProjectDefinition>";
const graphType = 'ReturnType<typeof prepareTaskGraph>["schedulerGraphSnapshot"]';
function builder(name: string, body: string | undefined, extraParameters = ""): string {
  assert(body !== undefined);
  return `function ${name}(fixture: SizedFixture${extraParameters}): readonly BenchmarkWorkload[] {\nconst {ids, size, iterations} = fixture;\nconst workloads: BenchmarkWorkload[] = [];\n${body}\nreturn workloads;\n}\n`;
}
const builders = [
  builder("identifierWorkloads", identifiers),
  builder("reasonWorkloads", reasons),
  `function normalizedFlagDefinition(ids: readonly string[]): ${normalizedType} {\n${flagSetup}\n}\n`,
  builder("flagWorkloads", flagWorkload, `, normalized: ${normalizedType}`),
  builder("dependencyWorkloads", dependencies),
  builder("artifactWorkloads", artifacts, `, normalized: ${normalizedType}`),
  `function graphPreparationWorkloads(fixture: SizedFixture): { readonly graph: ${graphType}; readonly workloads: readonly BenchmarkWorkload[] } {\nconst { ids, size, iterations } = fixture;\nconst workloads: BenchmarkWorkload[] = [];\n${graphWorkload}${graphResult}\nreturn {graph, workloads};\n}\n`,
  builder("criticalPathWorkloads", critical, `, graph: ${graphType}`),
  builder("durationHistoryWorkloads", history).replace(
    "const {ids, size, iterations}",
    "const {ids, size}"
  ),
  `async function learnedStrategyWorkloads(input: { readonly fixture: SizedFixture; readonly graph: ${graphType}; readonly stateRoot: string }): Promise<readonly BenchmarkWorkload[]> {\nconst {fixture, graph, stateRoot} = input;\nconst { ids, size, iterations } = fixture;\nconst workloads: BenchmarkWorkload[] = [];\n${learned}\nreturn workloads;\n}\n`
].join("\n");
const tailStart = sizedEnd + "\n  }".length;
const tail = transformed.slice(
  tailStart,
  transformed.lastIndexOf("  return Object.freeze(workloads);")
);
const tailSource = ts.createSourceFile(
  "tail.ts",
  `function tail() {${tail}}`,
  ts.ScriptTarget.Latest,
  true
);
const tailFunction = tailSource.statements[0];
assert(
  tailFunction !== undefined &&
    ts.isFunctionDeclaration(tailFunction) &&
    tailFunction.body !== undefined
);
const tailNames = [
  "exactKeyWorkloads",
  "areaIntersectionWorkloads",
  "sccBatchWorkloads",
  "markdownFindingWorkloads"
];
assert.equal(tailFunction.body.statements.length, tailNames.length);
const tailBuilders = tailFunction.body.statements
  .map((statement, index) => {
    return `function ${tailNames[index]}(): readonly BenchmarkWorkload[] {\nconst workloads: BenchmarkWorkload[] = [];\n${statement.getText(tailSource)}\nreturn workloads;\n}\n`;
  })
  .join("\n");
const factory = `
interface SizedFixture { readonly ids: readonly string[]; readonly size: number; readonly iterations: number; }

/** Temporary fixtures for this batch only; remove with the owning Change evidence. */
export async function createWorkloads(stateRoot: string): Promise<readonly BenchmarkWorkload[]> {
  const workloads: BenchmarkWorkload[] = [];
  for (const size of [8, 512]) {
    const fixture = { ids: idsFor(size), size, iterations: size === 8 ? 300 : 8 };
    workloads.push(...identifierWorkloads(fixture), ...reasonWorkloads(fixture));
    const normalized = normalizedFlagDefinition(fixture.ids);
    workloads.push(...flagWorkloads(fixture, normalized), ...dependencyWorkloads(fixture), ...artifactWorkloads(fixture, normalized));
    const preparedGraph = graphPreparationWorkloads(fixture);
    workloads.push(...preparedGraph.workloads, ...criticalPathWorkloads(fixture, preparedGraph.graph), ...durationHistoryWorkloads(fixture));
    workloads.push(...await learnedStrategyWorkloads({ fixture, graph: preparedGraph.graph, stateRoot }));
  }
  workloads.push(...exactKeyWorkloads(), ...areaIntersectionWorkloads(), ...sccBatchWorkloads(), ...markdownFindingWorkloads());
  return Object.freeze(workloads);
}
`;
const author = (authorPrefix + factory + builders + tailBuilders).replaceAll(
  "../before/",
  "__SOURCE_ROOT__/"
);
await writeFile(`${root}/candidate/harness/workloads-template.txt`, author);
for (const [mode, sourceRoot] of [
  ["before", "../before"],
  ["after", "../after-final"]
] as const) {
  await writeFile(
    `${root}/candidate/harness/${mode}-workloads.ts`,
    author.replaceAll("__SOURCE_ROOT__", sourceRoot)
  );
}
