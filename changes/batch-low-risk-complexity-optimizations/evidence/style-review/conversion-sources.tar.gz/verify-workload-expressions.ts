import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import ts from "/workspace/vibe-check/node_modules/typescript/lib/typescript.js";

// Temporary equivalence proof; retain with this Change's replay evidence.
const root = "/tmp/vibe-low-risk-style.9xQguq";
const printer = ts.createPrinter({ removeComments: true });
function expressionText(expression: ts.Node, source: ts.SourceFile): string {
  return printer.printNode(ts.EmitHint.Unspecified, expression, source);
}
async function descriptors(
  path: string,
  original: boolean
): Promise<readonly (readonly string[])[]> {
  const source = ts.createSourceFile(
    path,
    await readFile(path, "utf8"),
    ts.ScriptTarget.Latest,
    true
  );
  const found: string[][] = [];
  function visit(node: ts.Node): void {
    if (ts.isCallExpression(node)) {
      if (original && node.expression.getText(source) === "add") {
        found.push(node.arguments.map((argument) => expressionText(argument, source)));
      } else if (!original && node.expression.getText(source) === "workloads.push") {
        const descriptor = node.arguments[0];
        if (descriptor !== undefined && ts.isObjectLiteralExpression(descriptor)) {
          const fields = new Map<string, string>();
          for (const field of descriptor.properties) {
            if (ts.isPropertyAssignment(field)) {
              fields.set(field.name.getText(source), expressionText(field.initializer, source));
            } else if (ts.isShorthandPropertyAssignment(field)) {
              fields.set(field.name.text, field.name.text);
            } else {
              throw new Error("Unexpected workload descriptor field");
            }
          }
          found.push(
            ["name", "size", "iterations", "boundary", "invoke", "asynchronous"].map((field) => {
              const value = fields.get(field);
              if (value === undefined) throw new Error(`Missing workload field ${field}`);
              return value;
            })
          );
        }
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(source);
  return found.map((fields) => (fields.length === 5 ? [...fields, "false"] : fields));
}
const historical = await descriptors(`${root}/historical/harness/before-workloads.ts`, true);
const candidate = await descriptors(`${root}/candidate/harness/before-workloads.ts`, false);
assert.deepEqual(candidate, historical);
for (const [templateName, beforeName, afterName, afterRoot] of [
  ["workloads-template.txt", "before-workloads.ts", "after-workloads.ts", "../after-final"],
  ["c05-template.txt", "c05-before-workloads.ts", "c05-after-workloads.ts", "../c05-candidate"]
] as const) {
  const template = await readFile(`${root}/candidate/harness/${templateName}`, "utf8");
  assert.equal(
    await readFile(`${root}/candidate/harness/${beforeName}`, "utf8"),
    template.replaceAll("__SOURCE_ROOT__", "../before")
  );
  assert.equal(
    await readFile(`${root}/candidate/harness/${afterName}`, "utf8"),
    template.replaceAll("__SOURCE_ROOT__", afterRoot)
  );
}
function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
async function smokeMetadata(path: string): Promise<readonly Record<string, unknown>[]> {
  const result: unknown = JSON.parse(await readFile(path, "utf8"));
  assert(isRecord(result) && Array.isArray(result.rows));
  const rows: readonly unknown[] = result.rows;
  return rows.map((row) => {
    assert(isRecord(row));
    const metadata = { ...row };
    delete metadata.samplesMsPerCall;
    return metadata;
  });
}
assert.deepEqual(
  await smokeMetadata(`${root}/equivalence-results/smoke-before.json`),
  await smokeMetadata("/tmp/vibe-low-risk-review.5n66j6/comparison-results/smoke-before.json")
);
process.stdout.write(
  `Preserved ${candidate.length} descriptor expressions (including timed invoke bodies), all 37 smoke row metadata/output, and byte-identical template expansion.\n`
);
