import { readFile, writeFile } from "node:fs/promises";

// One-off source binding for this Change; retain only with its transformation evidence.
const harness = "/tmp/vibe-low-risk-style.9xQguq/candidate/harness";
const template = await readFile(`${harness}/workloads-template.txt`, "utf8");
for (const mode of ["before", "after"]) {
  await writeFile(
    `${harness}/style-${mode}-workloads.ts`,
    template.replaceAll("__SOURCE_ROOT__", `../style-${mode}`)
  );
}
const measurementSource = await readFile(`${harness}/measure.ts`, "utf8");
const styleMeasurement = measurementSource
  .replace(
    "function assertFactory(",
    "// Temporary wrapper-removal replay; retain this entry with the scoped Change evidence.\nfunction assertFactory("
  )
  .replace("./${mode}-workloads.ts", "./style-${mode}-workloads.ts")
  .replace(
    "usage: measure.ts before|after output.json [smoke]",
    "usage: measure-style.ts before|after output.json [smoke|formal] [all|flags]"
  )
  .replace(
    'const smoke = process.argv[4] === "smoke";',
    `const measurementMode = process.argv[4] ?? "formal";
if (measurementMode !== "smoke" && measurementMode !== "formal")
  throw new Error("style measurement mode must be smoke or formal");
const smoke = measurementMode === "smoke";`
  )
  .replace(
    "const artifactRoot =",
    `const workloadScope = process.argv[5] ?? "all";
if (workloadScope !== "all" && workloadScope !== "flags")
  throw new Error("style measurement scope must be all or flags");
const artifactRoot =`
  )
  .replace(
    "const workloads = await loaded.createWorkloads(stateRoot);",
    `const allWorkloads = await loaded.createWorkloads(stateRoot);
const workloads = workloadScope === "flags"
  ? allWorkloads.filter((workload) => workload.name === "R08-flag-membership")
  : allWorkloads;
assert.equal(workloads.length, workloadScope === "flags" ? 2 : 37);`
  );
await writeFile(`${harness}/measure-style.ts`, styleMeasurement);
