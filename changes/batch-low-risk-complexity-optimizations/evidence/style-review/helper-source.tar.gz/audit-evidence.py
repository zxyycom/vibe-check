"""Replay the original 37-workload evidence, never the current product revision.

Temporary Change audit: keep with replay evidence and remove with that Change.
The source directory is the original frozen after-final snapshot. Git baseline
reads still use the real repository; all original SHA checks remain mandatory.
"""

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess


@dataclass(frozen=True)
class AuditPaths:
    repository: Path
    source: Path
    evidence: Path
    raw: Path


PATHS = AuditPaths(
    repository=Path("/workspace/vibe-check"),
    source=Path("/tmp/vibe-low-risk-bench.OMhMtE/after-final"),
    evidence=Path("/workspace/vibe-check/changes/batch-low-risk-complexity-optimizations/evidence"),
    raw=Path("/tmp/vibe-low-risk-review.5n66j6"),
)
BASELINE = "b3c8fecce5a2ff835948f76f9fd4fa5a8e2fe853"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def manifest(path: Path) -> list[list[str]]:
    return [line.split("  ", 1) for line in path.read_text().splitlines()]


def verify_source_identities(paths: AuditPaths) -> None:
    source_manifests = [
        ("before", "before-src-sha256-relative.txt"),
        ("after", "after-final-src-sha256-relative.txt"),
    ]
    for mode, manifest_name in source_manifests:
        entries = manifest(paths.evidence / "identity" / manifest_name)
        for expected, relative in entries:
            if mode == "before":
                data = subprocess.check_output(
                    ["git", "show", f"{BASELINE}:{relative}"], cwd=paths.repository
                )
            else:
                data = (paths.source / relative).read_bytes()
            assert digest(data) == expected, (mode, relative)
        print(mode, "source SHA verified:", len(entries))


def verify_archived_bytes(paths: AuditPaths) -> None:
    for expected, relative in manifest(paths.evidence / "artifact-sha256.txt"):
        assert digest((paths.evidence / relative).read_bytes()) == expected, relative
    print("Archived delivery SHA verified")
    for expected, relative in manifest(paths.evidence / "raw-text-original-sha256.txt"):
        assert digest((paths.raw / relative).read_bytes()) == expected, relative
    print("Raw-text original bytes SHA verified")
    validation = paths.evidence / "root-validation"
    for expected, relative in manifest(validation / "artifact-sha256.txt"):
        assert digest((validation / relative).read_bytes()) == expected, relative
    print("Root-validation archive SHA verified")


def verify_original_workload_pair(paths: AuditPaths) -> None:
    before = (paths.raw / "harness/before-workloads.ts").read_text()
    after = (paths.raw / "harness/after-workloads.ts").read_text()
    assert before.replace("../before/", "../SOURCE/") == after.replace(
        "../after-final/", "../SOURCE/"
    )
    print("Before/after workload helper identical apart from source root")


def verify_raw_runs(paths: AuditPaths) -> dict:
    runs = {}
    for pair in range(5):
        for mode in ["before", "after"]:
            path = paths.raw / f"comparison-results/formal-0{pair}-{mode}.json"
            run = json.loads(path.read_text())
            assert run["mode"] == mode and len(run["rows"]) == 37
            assert path.with_suffix(".stderr.txt").stat().st_size == 0
            runs[pair, mode] = run
    assert len({run["processId"] for run in runs.values()}) == 10
    expected_order = "".join(
        f"{pair}\t{mode}\n"
        for pair in range(5)
        for mode in (["before", "after"] if pair % 2 == 0 else ["after", "before"])
    )
    actual_order = (paths.raw / "comparison-results/execution-order.txt").read_text()
    assert actual_order == expected_order
    return runs


def verify_row_observations(index: int, runs: dict, smokes: list) -> None:
    rows = [run["rows"][index] for run in runs.values()]
    for row in rows:
        for key in ["name", "size", "iterations", "boundary", "output"]:
            assert row[key] == rows[0][key], (index, key)
        assert len(row["samplesMsPerCall"]) == 7
        assert row["warmupCalls"] == 3 * row["iterations"]
    for smoke in smokes:
        assert smoke["rows"][index]["output"] == rows[0]["output"]


def verify_row_statistics(index: int, aggregate: dict, runs: dict) -> None:
    process_medians = {}
    for mode in ["before", "after"]:
        samples = [
            sample
            for pair in range(5)
            for sample in runs[pair, mode]["rows"][index]["samplesMsPerCall"]
        ]
        median = statistics.median(samples)
        expected_distribution = [
            ("median", median),
            ("mad", statistics.median(abs(sample - median) for sample in samples)),
            ("min", min(samples)),
            ("max", max(samples)),
            ("count", 35),
        ]
        distribution = aggregate[f"{mode}MsPerCall"]
        for key, expected in expected_distribution:
            assert math.isclose(distribution[key], expected, rel_tol=1e-14), (index, key)
        process_medians[mode] = [
            statistics.median(runs[pair, mode]["rows"][index]["samplesMsPerCall"])
            for pair in range(5)
        ]
        assert aggregate[f"{mode}ProcessMedians"] == process_medians[mode]
    ratios = [
        after / before
        for after, before in zip(process_medians["after"], process_medians["before"])
    ]
    assert aggregate["pairedAfterOverBefore"] == ratios
    assert aggregate["afterOverBefore"] == (
        aggregate["afterMsPerCall"]["median"] / aggregate["beforeMsPerCall"]["median"]
    )
    print(aggregate["name"], aggregate["size"], "paired median", round(statistics.median(ratios), 4))


def verify_paired_statistics(paths: AuditPaths) -> None:
    summary_path = paths.evidence / "summary.json"
    summary = json.loads(summary_path.read_text())
    assert len(summary["rows"]) == 37
    assert (paths.raw / "comparison-results/summary.json").read_bytes() == summary_path.read_bytes()
    runs = verify_raw_runs(paths)
    smokes = [
        json.loads((paths.raw / f"comparison-results/smoke-{mode}.json").read_text())
        for mode in ["before", "after"]
    ]
    for index, aggregate in enumerate(summary["rows"]):
        verify_row_observations(index, runs, smokes)
        verify_row_statistics(index, aggregate, runs)
    print(
        "All 37 workload full-output parity, metadata, 2590 batch samples "
        "and paired statistics independently verified"
    )


def main() -> None:
    verify_source_identities(PATHS)
    verify_archived_bytes(PATHS)
    verify_original_workload_pair(PATHS)
    verify_paired_statistics(PATHS)


if __name__ == "__main__":
    main()
