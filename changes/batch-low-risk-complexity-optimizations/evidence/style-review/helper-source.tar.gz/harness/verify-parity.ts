import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
function isRecord(candidate: unknown): candidate is Record<string, unknown> {
  return candidate !== null && typeof candidate === "object" && !Array.isArray(candidate);
}
function comparableRows(
  candidate: unknown
): readonly { readonly name: string; readonly size: number; readonly output: string }[] {
  if (!isRecord(candidate) || !Array.isArray(candidate.rows))
    throw new Error("missing result rows");
  const rows: readonly unknown[] = candidate.rows;
  return rows.map((row) => {
    if (
      !isRecord(row) ||
      typeof row.name !== "string" ||
      typeof row.size !== "number" ||
      typeof row.output !== "string"
    )
      throw new Error("invalid result row");
    return { name: row.name, size: row.size, output: row.output };
  });
}
const beforePath = process.argv[2];
const afterPath = process.argv[3];
if (beforePath === undefined || afterPath === undefined)
  throw new Error("usage: verify-parity.ts before.json after.json");
const before: unknown = JSON.parse(await readFile(beforePath, "utf8"));
const after: unknown = JSON.parse(await readFile(afterPath, "utf8"));
const beforeRows = comparableRows(before);
assert.deepEqual(comparableRows(after), beforeRows);
process.stdout.write(
  `Full serialized output and ordered workload identity parity: ${beforeRows.length} workloads.\n`
);
