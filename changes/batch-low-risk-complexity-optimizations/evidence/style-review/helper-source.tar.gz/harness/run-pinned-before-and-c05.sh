#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")/.." && pwd)
source "$root/harness/pinned-runtime.sh"
cd "$root/harness"
for scope in pinned-before-results pinned-c05-results; do test ! -e "$root/$scope"; mkdir "$root/$scope"; done
out="$root/pinned-before-results"
"$bun_binary" run measure.ts before "$out/smoke-before.json" smoke > "$out/smoke-before.stdout.txt" 2> "$out/smoke-before.stderr.txt"
date -u +%FT%TZ > "$out/window-start.txt"
for pair in 0 1 2 3 4; do
  "$bun_binary" run measure.ts before "$out/formal-0${pair}-before.json" > "$out/formal-0${pair}-before.stdout.txt" 2> "$out/formal-0${pair}-before.stderr.txt"
done
date -u +%FT%TZ > "$out/window-end.txt"
"$bun_binary" run summarize.ts "$out" "$out/summary.json" > "$out/summary.txt"
out="$root/pinned-c05-results"
"$bun_binary" run c05-equivalence.ts > "$out/equivalence.txt"
"$bun_binary" run c05-measure.ts before "$out/smoke-before.json" smoke > "$out/smoke-before.stdout.txt" 2> "$out/smoke-before.stderr.txt"
"$bun_binary" run c05-measure.ts after "$out/smoke-after.json" smoke > "$out/smoke-after.stdout.txt" 2> "$out/smoke-after.stderr.txt"
"$bun_binary" run verify-parity.ts "$out/smoke-before.json" "$out/smoke-after.json" > "$out/pre-timing-parity.txt"
date -u +%FT%TZ > "$out/window-start.txt"
for pair in 0 1 2 3 4; do
  if (( pair % 2 == 0 )); then modes='before after'; else modes='after before'; fi
  for mode in $modes; do
    printf '%s\t%s\n' "$pair" "$mode" >> "$out/execution-order.txt"
    "$bun_binary" run c05-measure.ts "$mode" "$out/formal-0${pair}-${mode}.json" > "$out/formal-0${pair}-${mode}.stdout.txt" 2> "$out/formal-0${pair}-${mode}.stderr.txt"
  done
done
date -u +%FT%TZ > "$out/window-end.txt"
"$bun_binary" run summarize.ts "$out" "$out/summary.json" > "$out/summary.txt"
