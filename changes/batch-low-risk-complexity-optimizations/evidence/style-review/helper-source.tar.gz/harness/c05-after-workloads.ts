import { hasExactPlainRecordKeys } from "../c05-candidate/src/data-boundary/closed-values.ts";
import type { BenchmarkWorkload } from "./benchmark-contract.ts";
export function createWorkloads(): Promise<readonly BenchmarkWorkload[]> {
  const workloads = [2, 5, 512].map((size) => {
    const keys = Array.from({ length: size }, (_, index) => `key-${index}`);
    const record = Object.fromEntries(keys.map((key, index) => [key, index]));
    const wrongSameLength = Object.fromEntries(
      keys.map((key, index) => [index === 0 ? "unknown" : key, index])
    );
    const wrongLength = { ...record, extra: true };
    return {
      name: "C05-isolated-once-per-call-Set",
      size,
      iterations: size <= 5 ? 100000 : 100,
      boundary:
        "hasExactPlainRecordKeys: 2 valid calls + equal-length unknown + length mismatch; all records/keys preconstructed; Set creation remains inside every eligible call",
      asynchronous: false,
      invoke: () => [
        hasExactPlainRecordKeys(record, keys),
        hasExactPlainRecordKeys(record, keys),
        hasExactPlainRecordKeys(wrongSameLength, keys),
        hasExactPlainRecordKeys(wrongLength, keys)
      ]
    };
  });
  return Promise.resolve(workloads);
}
