#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")/.." && pwd)
source "$root/harness/pinned-runtime.sh"
out="$root/comparison-results"
# Dedicated output namespace retains earlier 31-workload baseline/C05 unchanged.
test ! -e "$out"
mkdir "$out"
cd "$root/harness"
"$bun_binary" run measure.ts before "$out/smoke-before.json" smoke > "$out/smoke-before.stdout.txt" 2> "$out/smoke-before.stderr.txt"
"$bun_binary" run measure.ts after "$out/smoke-after.json" smoke > "$out/smoke-after.stdout.txt" 2> "$out/smoke-after.stderr.txt"
"$bun_binary" run verify-parity.ts "$out/smoke-before.json" "$out/smoke-after.json" > "$out/pre-timing-parity.txt"
date -u +%FT%TZ > "$out/window-start.txt"
for pair in 0 1 2 3 4; do
  if (( pair % 2 == 0 )); then modes='before after'; else modes='after before'; fi
  for mode in $modes; do
    output="$out/formal-0${pair}-${mode}.json"
    test ! -e "$output"
    printf '%s\t%s\n' "$pair" "$mode" >> "$out/execution-order.txt"
    "$bun_binary" run measure.ts "$mode" "$output" > "$out/formal-0${pair}-${mode}.stdout.txt" 2> "$out/formal-0${pair}-${mode}.stderr.txt"
  done
done
date -u +%FT%TZ > "$out/window-end.txt"
"$bun_binary" run summarize.ts "$out" "$out/summary.json" > "$out/summary.txt"
