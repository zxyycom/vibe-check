#!/usr/bin/env bash
# Temporary style-before/style-after check for this Change's wrapper removal only.
# Reuse original iteration/warmup/batch protocol, not a new benchmark framework.
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")/.." && pwd)
source "$root/harness/pinned-runtime.sh"
out="$root/style-flags-results"
test ! -e "$out"
mkdir "$out"
cd "$root/harness"
date -u +%FT%TZ > "$out/window-start.txt"
for pair in 0 1 2 3 4; do
  if (( pair % 2 == 0 )); then modes='before after'; else modes='after before'; fi
  for mode in $modes; do
    output="$out/formal-0${pair}-${mode}.json"
    test ! -e "$output"
    printf '%s\t%s\n' "$pair" "$mode" >> "$out/execution-order.txt"
    "$bun_binary" run measure-style.ts "$mode" "$output" formal flags > "$out/formal-0${pair}-${mode}.stdout.txt" 2> "$out/formal-0${pair}-${mode}.stderr.txt"
  done
done
date -u +%FT%TZ > "$out/window-end.txt"
"$bun_binary" run summarize.ts "$out" "$out/summary.json" > "$out/summary.txt"
