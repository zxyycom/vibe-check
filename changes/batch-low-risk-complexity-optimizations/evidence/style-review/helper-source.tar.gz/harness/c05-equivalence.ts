import assert from "node:assert/strict";
import { hasExactPlainRecordKeys as before } from "../before/src/data-boundary/closed-values.ts";
import { hasExactPlainRecordKeys as candidate } from "../c05-candidate/src/data-boundary/closed-values.ts";
const fields = ["a", "b", "__proto__", "constructor"];
let checked = 0;
for (let mask = 0; mask < 16; mask += 1) {
  const selected = fields.filter((_, index) => (mask & (1 << index)) !== 0);
  const record = Object.fromEntries(selected.map((field) => [field, undefined]));
  for (let keysMask = 0; keysMask < 16; keysMask += 1) {
    const keys = fields.filter((_, index) => (keysMask & (1 << index)) !== 0);
    for (const schema of [keys, [...keys].reverse(), [...keys, ...keys]]) {
      assert.equal(candidate(record, schema), before(record, schema));
      checked += 1;
    }
  }
}
process.stdout.write(
  `Exact-key boolean equivalence: ${checked} cases including empty, reordered, missing, extra, and duplicate schema keys.\n`
);
