import assert from "node:assert/strict";
import { readdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import type { BenchmarkResult, BenchmarkRow } from "./benchmark-contract.ts";
function isRecord(candidate: unknown): candidate is Record<string, unknown> {
  return candidate !== null && typeof candidate === "object" && !Array.isArray(candidate);
}
function assertRow(candidate: unknown): asserts candidate is BenchmarkRow {
  if (
    !isRecord(candidate) ||
    typeof candidate.name !== "string" ||
    typeof candidate.size !== "number" ||
    typeof candidate.output !== "string" ||
    typeof candidate.boundary !== "string" ||
    typeof candidate.iterations !== "number" ||
    typeof candidate.warmupCalls !== "number" ||
    !Array.isArray(candidate.samplesMsPerCall)
  )
    throw new Error("invalid benchmark row");
  const samples: readonly unknown[] = candidate.samplesMsPerCall;
  if (
    samples.length === 0 ||
    samples.some((sample) => typeof sample !== "number" || !Number.isFinite(sample) || sample < 0)
  )
    throw new Error("invalid samples");
}
function assertResult(candidate: unknown): asserts candidate is BenchmarkResult {
  if (!isRecord(candidate) || typeof candidate.mode !== "string" || !Array.isArray(candidate.rows))
    throw new Error("invalid benchmark result");
  const rows: readonly unknown[] = candidate.rows;
  for (const row of rows) assertRow(row);
}
function median(samples: readonly number[]): number {
  const sorted = [...samples].sort((left, right) => left - right);
  const middle = Math.floor(sorted.length / 2);
  const right = sorted[middle];
  if (right === undefined) throw new Error("median requires samples");
  if (sorted.length % 2 === 1) return right;
  const left = sorted[middle - 1];
  if (left === undefined) throw new Error("missing median neighbor");
  return (left + right) / 2;
}
function distribution(samples: readonly number[]) {
  const center = median(samples);
  return {
    median: center,
    mad: median(samples.map((sample) => Math.abs(sample - center))),
    min: Math.min(...samples),
    max: Math.max(...samples),
    count: samples.length
  };
}
const directory = process.argv[2];
const target = process.argv[3];
if (directory === undefined || target === undefined)
  throw new Error("usage: summarize.ts raw-directory summary.json");
const files = (await readdir(directory))
  .filter((name) => /^formal-\d+-(before|after)\.json$/.test(name))
  .sort();
const runs: BenchmarkResult[] = [];
for (const file of files) {
  const candidate: unknown = JSON.parse(await readFile(join(directory, file), "utf8"));
  assertResult(candidate);
  runs.push(candidate);
}
const first = runs[0];
if (first === undefined) throw new Error("no formal results");
for (const run of runs) assert.equal(run.rows.length, first.rows.length);
const rows = first.rows.map((reference, rowIndex) => {
  const paired: { readonly mode: string; readonly row: BenchmarkRow }[] = runs.map((run) => {
    const row = run.rows[rowIndex];
    if (row === undefined) throw new Error("missing corresponding row");
    assert.equal(row.name, reference.name);
    assert.equal(row.size, reference.size);
    assert.equal(row.iterations, reference.iterations);
    assert.equal(row.boundary, reference.boundary);
    assert.equal(row.output, reference.output, `${row.name}/${row.size} full output mismatch`);
    return { mode: run.mode, row };
  });
  const before = paired.filter((entry) => entry.mode === "before").map((entry) => entry.row);
  const after = paired.filter((entry) => entry.mode === "after").map((entry) => entry.row);
  const beforeProcessMedians = before.map((row) => median(row.samplesMsPerCall));
  const afterProcessMedians = after.map((row) => median(row.samplesMsPerCall));
  const beforeMs = distribution(before.flatMap((row) => row.samplesMsPerCall));
  const afterMs =
    after.length === 0 ? null : distribution(after.flatMap((row) => row.samplesMsPerCall));
  const pairedAfterOverBefore = afterProcessMedians.map((afterMedian, index) => {
    const beforeMedian = beforeProcessMedians[index];
    if (beforeMedian === undefined || beforeMedian <= 0) throw new Error("missing before pair");
    return afterMedian / beforeMedian;
  });
  return {
    name: reference.name,
    size: reference.size,
    boundary: reference.boundary,
    iterations: reference.iterations,
    fullOutputParity: true,
    beforeMsPerCall: beforeMs,
    afterMsPerCall: afterMs,
    afterOverBefore: afterMs === null ? null : afterMs.median / beforeMs.median,
    beforeProcessMedians,
    afterProcessMedians,
    pairedAfterOverBefore
  };
});
await writeFile(
  target,
  `${JSON.stringify({ protocol: "independent process before/after; 3 iteration-batch warmup calls; 7 measured batches; no sample exclusions; median and unscaled median absolute deviation; pooled batches are not independent experiments", files, rows }, null, 2)}\n`
);
for (const row of rows)
  process.stdout.write(
    `${row.name}/${row.size}: B=${row.beforeMsPerCall.median.toFixed(6)}ms (MAD ${row.beforeMsPerCall.mad.toFixed(6)}), A=${row.afterMsPerCall?.median.toFixed(6) ?? "pending"}, A/B=${row.afterOverBefore?.toFixed(3) ?? "pending"}\n`
  );
