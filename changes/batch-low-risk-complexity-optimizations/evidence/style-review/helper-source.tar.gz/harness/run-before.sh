#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")/.." && pwd)
cd "$root/harness"
for sample in 00 01 02 03 04; do
  output="$root/results/formal-${sample}-before.json"
  test ! -e "$output"
  bun run measure.ts before "$output" > "$root/results/formal-${sample}-before.stdout.txt" 2> "$root/results/formal-${sample}-before.stderr.txt"
done
bun run summarize.ts "$root/results" "$root/results/before-summary.json" > "$root/results/before-summary.txt"
