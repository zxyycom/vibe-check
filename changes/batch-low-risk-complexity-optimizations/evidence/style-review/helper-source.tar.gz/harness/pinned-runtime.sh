#!/usr/bin/env bash
# Resolved from workspace mise which; already installed, no installation.
bun_binary=/home/dev/.local/share/mise/installs/bun/1.3.14/bin/bun
node_binary=/home/dev/.local/share/mise/installs/node/24.18.0/bin/node
export PATH="$(dirname "$bun_binary"):$(dirname "$node_binary"):$PATH"
test "$("$bun_binary" --version)" = 1.3.14
test "$("$node_binary" --version)" = v24.18.0
