export interface BenchmarkWorkload {
  readonly name: string;
  readonly size: number;
  readonly iterations: number;
  readonly boundary: string;
  readonly invoke: (() => unknown) | (() => Promise<unknown>);
  readonly asynchronous: boolean;
}
export interface BenchmarkFactory {
  readonly createWorkloads: (stateRoot: string) => Promise<readonly BenchmarkWorkload[]>;
}
export interface BenchmarkRow {
  readonly name: string;
  readonly size: number;
  readonly iterations: number;
  readonly boundary: string;
  readonly output: string;
  readonly warmupCalls: number;
  readonly samplesMsPerCall: readonly number[];
}
export interface BenchmarkResult {
  readonly mode: string;
  readonly rows: readonly BenchmarkRow[];
}
