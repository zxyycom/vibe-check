import assert from "node:assert/strict";
import { writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import type { BenchmarkFactory, BenchmarkRow, BenchmarkWorkload } from "./benchmark-contract.ts";

// Temporary wrapper-removal replay; retain this entry with the scoped Change evidence.
function assertFactory(candidate: unknown): asserts candidate is BenchmarkFactory {
  if (
    candidate === null ||
    typeof candidate !== "object" ||
    !("createWorkloads" in candidate) ||
    typeof candidate.createWorkloads !== "function"
  )
    throw new Error("workload factory missing");
}
function serialize(output: unknown): string {
  return JSON.stringify(output) ?? "undefined";
}
const mode = process.argv[2];
if (mode !== "before" && mode !== "after")
  throw new Error("usage: measure-style.ts before|after output.json [smoke|formal] [all|flags]");
const target = process.argv[3];
if (target === undefined) throw new Error("output target required");
const measurementMode = process.argv[4] ?? "formal";
if (measurementMode !== "smoke" && measurementMode !== "formal")
  throw new Error("style measurement mode must be smoke or formal");
const smoke = measurementMode === "smoke";
const workloadScope = process.argv[5] ?? "all";
if (workloadScope !== "all" && workloadScope !== "flags")
  throw new Error("style measurement scope must be all or flags");
const artifactRoot = fileURLToPath(new URL("../", import.meta.url));
const loaded: unknown = await import(new URL(`./style-${mode}-workloads.ts`, import.meta.url).href);
assertFactory(loaded);
const stateRoot = join(artifactRoot, "state", `${mode}-${process.pid}`);
await mkdir(stateRoot, { recursive: true });
const allWorkloads = await loaded.createWorkloads(stateRoot);
const workloads =
  workloadScope === "flags"
    ? allWorkloads.filter((workload) => workload.name === "R08-flag-membership")
    : allWorkloads;
assert.equal(workloads.length, workloadScope === "flags" ? 2 : 37);
const rows: BenchmarkRow[] = [];
async function measure(workload: BenchmarkWorkload): Promise<BenchmarkRow> {
  const expected = serialize(await workload.invoke());
  const iterations = smoke ? 1 : workload.iterations;
  const warmupCalls = smoke ? 1 : 3 * iterations;
  for (let index = 0; index < warmupCalls; index += 1)
    assert.equal(
      serialize(await workload.invoke()),
      expected,
      `${workload.name} warmup output drift`
    );
  const samplesMsPerCall: number[] = [];
  for (let batch = 0; batch < (smoke ? 1 : 7); batch += 1) {
    let lastOutput: unknown;
    const started = performance.now();
    if (workload.asynchronous) {
      for (let iteration = 0; iteration < iterations; iteration += 1)
        lastOutput = await workload.invoke();
    } else {
      for (let iteration = 0; iteration < iterations; iteration += 1)
        lastOutput = workload.invoke();
    }
    const elapsed = performance.now() - started;
    samplesMsPerCall.push(elapsed / iterations);
    assert.equal(serialize(lastOutput), expected, `${workload.name} batch output drift`);
  }
  return {
    name: workload.name,
    size: workload.size,
    boundary: workload.boundary,
    iterations,
    output: expected,
    warmupCalls,
    samplesMsPerCall
  };
}
for (const workload of workloads) rows.push(await measure(workload));
await writeFile(
  target,
  `${JSON.stringify({ mode, processId: process.pid, formedAt: new Date().toISOString(), rows }, null, 2)}\n`
);
process.stdout.write(`Completed ${mode}: ${rows.length} workloads -> ${target}\n`);
