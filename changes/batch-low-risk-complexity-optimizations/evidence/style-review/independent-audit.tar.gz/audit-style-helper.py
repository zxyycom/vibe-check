"""Read-only frozen helper/result audit for this review; retain only with its report."""
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import statistics
import tarfile


@dataclass(frozen=True)
class ReviewPaths:
    repository: Path
    candidate: Path
    historical: Path
    style: Path
    previous_review: Path


PATHS = ReviewPaths(
    repository=Path('/workspace/vibe-check'),
    candidate=Path('/tmp/vibe-low-risk-style.9xQguq/candidate'),
    historical=Path('/tmp/vibe-low-risk-style.9xQguq/historical'),
    style=Path('/tmp/vibe-low-risk-style.9xQguq'),
    previous_review=Path('/tmp/vibe-low-risk-review.5n66j6'),
)


def read_object(path: Path) -> dict:
    decoded = json.loads(path.read_text())
    assert isinstance(decoded, dict), path
    return decoded


def verify_manifest(manifest_path: Path, source_root: Path) -> dict[str, str]:
    entries = {}
    for line in manifest_path.read_text().splitlines():
        digest, relative = line.split('  ', 1)
        assert relative not in entries and not Path(relative).is_absolute(), relative
        assert hashlib.sha256((source_root / relative).read_bytes()).hexdigest() == digest, relative
        entries[relative] = digest
    return entries


def verify_frozen_sources(paths: ReviewPaths) -> None:
    helper = verify_manifest(paths.style / 'candidate-helper-sha256.txt', paths.candidate)
    before = verify_manifest(paths.style / 'style-before-src-sha256.txt', paths.candidate / 'style-before')
    after = verify_manifest(paths.style / 'style-after-src-sha256.txt', paths.candidate / 'style-after')
    assert len(before) == len(after) == 722 and before.keys() == after.keys()
    changed = [name for name in before if before[name] != after[name]]
    assert changed == ['src/project-run/check-execution/flag-controls.ts'], changed
    for relative, digest in after.items():
        assert hashlib.sha256((paths.repository / relative).read_bytes()).hexdigest() == digest, relative
    expected_files = {
        str(path.relative_to(paths.candidate / 'style-after'))
        for path in (paths.candidate / 'style-after/src').rglob('*') if path.is_file()
    }
    assert expected_files == set(after)
    evidence = paths.repository / 'changes/batch-low-risk-complexity-optimizations/evidence'
    assert (paths.style / 'style-before-src-sha256.txt').read_bytes() == (evidence / 'identity/after-final-src-sha256-relative.txt').read_bytes()
    for archive_path, target_root in [
        (evidence / 'helper-source.tar.gz', paths.historical),
        (evidence / 'independent-review/audit-script.tar.gz', paths.historical),
    ]:
        with tarfile.open(archive_path) as archive:
            for member in archive.getmembers():
                if member.isfile():
                    archived = archive.extractfile(member)
                    assert archived is not None
                    assert archived.read() == (target_root / member.name).read_bytes(), member.name
    for template_name, generated_roots in [
        ('workloads-template.txt', {'before-workloads.ts': '../before', 'after-workloads.ts': '../after-final', 'style-before-workloads.ts': '../style-before', 'style-after-workloads.ts': '../style-after'}),
        ('c05-template.txt', {'c05-before-workloads.ts': '../before', 'c05-after-workloads.ts': '../c05-candidate'}),
    ]:
        template = (paths.candidate / 'harness' / template_name).read_text()
        for generated_name, source_root in generated_roots.items():
            assert template.replace('__SOURCE_ROOT__', source_root) == (paths.candidate / 'harness' / generated_name).read_text(), generated_name
    print(f'Frozen helper {len(helper)} files, each source 722, one product change, original archive bytes, six template expansions verified')


def verify_smoke_and_prior_outputs(paths: ReviewPaths) -> None:
    for mode in ['before', 'after', 'current']:
        previous_mode = 'after' if mode == 'current' else mode
        reference = read_object(paths.previous_review / f'comparison-results/smoke-{previous_mode}.json')['rows']
        observed = read_object(paths.style / f'equivalence-results/smoke-{mode}.json')['rows']
        assert isinstance(reference, list) and isinstance(observed, list)
        assert len(reference) == len(observed) == 37
        for expected, actual in zip(reference, observed):
            assert isinstance(expected, dict) and isinstance(actual, dict)
            assert {key: value for key, value in expected.items() if key != 'samplesMsPerCall'} == {key: value for key, value in actual.items() if key != 'samplesMsPerCall'}
        assert (paths.style / f'equivalence-results/smoke-{mode}.stderr.txt').stat().st_size == 0
    for name in ['summary.json', 'summary.txt']:
        assert (paths.style / 'equivalence-results' / name).read_bytes() == (paths.previous_review / 'comparison-results' / name).read_bytes(), name
    assert (paths.style / 'original-audit-output.txt').read_bytes() == (paths.style / 'candidate-audit-output.txt').read_bytes()
    assert len((paths.style / 'candidate-audit-output.txt').read_text().splitlines()) == 44
    print('All three 37-row smoke metadata/full outputs, original summary JSON/stdout and 44-line audit stdout match')


def verify_new_flags_results(paths: ReviewPaths) -> None:
    directory = paths.candidate / 'style-flags-results'
    summary = read_object(directory / 'summary.json')
    runs = {}
    for pair in range(5):
        for mode in ['before', 'after']:
            path = directory / f'formal-0{pair}-{mode}.json'
            run = read_object(path)
            assert run['mode'] == mode and len(run['rows']) == 2
            assert path.with_suffix('.stderr.txt').stat().st_size == 0
            assert path.with_suffix('.stdout.txt').read_text().startswith(f'Completed {mode}: 2 workloads -> ')
            runs[pair, mode] = run
    assert len({run['processId'] for run in runs.values()}) == 10
    expected_order = ''.join(f'{pair}\t{mode}\n' for pair in range(5) for mode in (['before', 'after'] if pair % 2 == 0 else ['after', 'before']))
    assert (directory / 'execution-order.txt').read_text() == expected_order
    assert sorted(path.name for path in directory.glob('formal-*.json')) == summary['files']
    total_samples = 0
    for index, size in enumerate([8, 512]):
        aggregate = summary['rows'][index]
        reference = runs[0, 'before']['rows'][index]
        assert reference['name'] == 'R08-flag-membership' and reference['size'] == size
        assert reference['iterations'] == (300 if size == 8 else 8)
        process_medians = {}
        for mode in ['before', 'after']:
            rows = [runs[pair, mode]['rows'][index] for pair in range(5)]
            for row in rows:
                for key in ['name', 'size', 'iterations', 'boundary', 'output']:
                    assert row[key] == reference[key], (size, key)
                assert row['warmupCalls'] == 3 * row['iterations'] and len(row['samplesMsPerCall']) == 7
                assert all(isinstance(value, (int, float)) and math.isfinite(value) and value >= 0 for value in row['samplesMsPerCall'])
            samples = [value for row in rows for value in row['samplesMsPerCall']]
            total_samples += len(samples)
            center = statistics.median(samples)
            expected_distribution = {'median': center, 'mad': statistics.median(abs(value-center) for value in samples), 'min': min(samples), 'max': max(samples), 'count': len(samples)}
            assert aggregate[f'{mode}MsPerCall'] == expected_distribution
            process_medians[mode] = [statistics.median(row['samplesMsPerCall']) for row in rows]
            assert aggregate[f'{mode}ProcessMedians'] == process_medians[mode]
        paired = [after / before for after, before in zip(process_medians['after'], process_medians['before'])]
        assert aggregate['pairedAfterOverBefore'] == paired
        pooled = aggregate['afterMsPerCall']['median'] / aggregate['beforeMsPerCall']['median']
        assert aggregate['afterOverBefore'] == pooled and aggregate['fullOutputParity'] is True
        assert json.loads(reference['output']) == [f'id-{number:05}' for number in range(size)]
        print(f'flags/{size}: 70 samples; pooled {pooled:.9f}, paired median {statistics.median(paired):.9f}, slower {sum(ratio > 1 for ratio in paired)}/5; all statistics/output/order agree')
    assert total_samples == 140
    print('10 independent PIDs, alternating five pairs, exact 140 samples, no exclusions independently checked')


def main() -> None:
    verify_frozen_sources(PATHS)
    verify_smoke_and_prior_outputs(PATHS)
    verify_new_flags_results(PATHS)


if __name__ == '__main__':
    main()
